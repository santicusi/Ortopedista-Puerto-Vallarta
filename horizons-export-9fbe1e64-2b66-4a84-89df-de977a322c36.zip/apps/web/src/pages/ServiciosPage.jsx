import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Activity, Scissors, ActivitySquare, MessageCircle, ShieldPlus, PersonStanding, Phone, CheckCircle2, Ligature as Bandage, Syringe, Bone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const ServiciosPage = () => {
  useEffect(() => {
    const handleGlobalClick = (e) => {
      const target = e.target.closest('a, button');
      if (!target) return;

      const href = target.getAttribute('href') || '';
      const isWhatsApp = href.includes('wa.me') || href.includes('whatsapp');
      const text = target.textContent.toLowerCase();
      const isContactCTA = text.includes('agendar') || text.includes('llamar') || text.includes('contacto');

      if (isWhatsApp || isContactCTA) {
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'conversion', {
            'send_to': 'AW-17964727570/6hAZCOOf1fsbEJL6n_ZC',
            'value': 1.0,
            'currency': 'COP'
          });
        }
      }
    };

    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  const services = [
    {
      icon: ShieldPlus,
      title: 'Urgencias 24H',
      description: 'Atención médica inmediata y especializada para lesiones agudas del sistema musculoesquelético. Contamos con disponibilidad 24/7.',
      isEmergency: true,
      anchorId: 'urgencias'
    },
    {
      icon: Activity,
      title: 'Dolor de Espalda y Cuello',
      description: 'Evaluación exhaustiva de la columna vertebral para tratar lumbalgias, cervicalgias, hernias discales y ciática.',
      anchorId: 'espalda-cuello'
    },
    {
      icon: ActivitySquare,
      title: 'Dolor de Rodillas',
      description: 'Diagnóstico preciso de las causas del dolor de rodilla, incluyendo desgaste del cartílago, lesiones de meniscos y ligamentos.',
      anchorId: 'rodillas'
    },
    {
      icon: Scissors,
      title: 'Cirugía de Rodilla y Cadera',
      description: 'Intervenciones quirúrgicas avanzadas para restaurar la función de la rodilla, incluyendo artroscopias y reemplazos articulares.',
      anchorId: 'cirugia-rodilla'
    },
    {
      icon: PersonStanding,
      title: 'Dolor de Pie y Tobillo',
      description: 'Tratamiento especializado para afecciones complejas del pie y tobillo, incluyendo fascitis plantar y esguinces crónicos.',
      anchorId: 'pie-tobillo'
    },
    {
      icon: Bandage,
      title: 'Inmovilizaciones',
      description: 'Aplicación profesional de yesos, férulas y vendajes especializados para estabilizar lesiones y promover una correcta recuperación.',
      anchorId: 'inmovilizaciones',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20cita%20para%20Inmovilizaciones'
    },
    {
      icon: Syringe,
      title: 'Infiltraciones',
      description: 'Tratamiento mínimamente invasivo para aliviar el dolor articular severo y reducir la inflamación de manera rápida y efectiva.',
      anchorId: 'infiltraciones',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20cita%20para%20Infiltraciones'
    },
    {
      icon: Activity,
      title: 'Dolor de espalda',
      description: 'Manejo integral del dolor lumbar y cervical mediante enfoques conservadores y terapias avanzadas para mejorar tu calidad de vida.',
      anchorId: 'dolor-espalda',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20cita%20para%20Dolor%20de%20espalda'
    },
    {
      icon: Bone,
      title: 'Fracturas y Luxaciones',
      description: 'Manejo integral de huesos rotos y articulaciones dislocadas. Utilizamos técnicas de vanguardia y osteosíntesis.',
      anchorId: 'fracturas',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20cita%20por%20Fracturas%20y%20Luxaciones.'
    }
  ];

  const expandedServices = [
    {
      id: 'urgencias',
      title: 'Urgencias 24H',
      description: 'Atención médica inmediata y especializada para lesiones agudas del sistema musculoesquelético. Contamos con disponibilidad 24/7 para estabilización, diagnóstico por imagen y tratamiento definitivo, ya sea conservador o quirúrgico.',
      symptoms: ['Dolor insoportable tras un traumatismo', 'Deformidad evidente en una extremidad', 'Incapacidad total para mover una articulación', 'Hinchazón rápida y severa con hematoma'],
      whenToConsult: 'Acude inmediatamente si sufres un accidente, caída fuerte o lesión deportiva que te impida continuar con tus actividades, genere dolor intenso o sospeches de una fractura.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/0b03aeef46954214a782588e1c6a2464.png',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20de%20urgencia%20con%20el%20Dr.%20Calvario.'
    },
    {
      id: 'espalda-cuello',
      title: 'Dolor de Espalda y Cuello',
      description: 'Evaluación exhaustiva de la columna vertebral para tratar lumbalgias, cervicalgias, hernias discales y ciática. Nuestro enfoque busca aliviar el dolor, desinflamar los nervios afectados y restaurar la biomecánica de la columna.',
      symptoms: ['Dolor punzante o sordo en la zona lumbar o cervical', 'Dolor que se irradia hacia los brazos o piernas (ciática)', 'Hormigueo, entumecimiento o debilidad', 'Rigidez muscular que limita el movimiento'],
      whenToConsult: 'Cuando el dolor de espalda dura más de unas semanas, no mejora con descanso, se irradia a las extremidades o se acompaña de debilidad muscular o pérdida de sensibilidad.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/666f0546ce880baa7462eda7b17d66b6.png',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20dolor%20de%20espalda%20y%20cuello.'
    },
    {
      id: 'rodillas',
      title: 'Dolor de Rodillas',
      description: 'Diagnóstico preciso de las causas del dolor de rodilla, incluyendo desgaste del cartílago (osteoartritis), lesiones de meniscos, tendinitis y problemas de ligamentos. Ofrecemos tratamientos desde infiltraciones hasta rehabilitación.',
      symptoms: ['Dolor al subir o bajar escaleras', 'Sensación de chasquido o bloqueo en la articulación', 'Inflamación y rigidez matutina', 'Inestabilidad o sensación de que la rodilla "falla"'],
      whenToConsult: 'Si el dolor interfiere con tus actividades diarias, notas hinchazón persistente, no puedes extender completamente la pierna o sientes inestabilidad al caminar.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/6dbf8f83340ad6ab8f81a65b1beba240.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20dolor%20de%20rodillas.'
    },
    {
      id: 'cirugia-rodilla',
      title: 'Cirugía de Rodilla y Cadera',
      description: 'Intervenciones quirúrgicas avanzadas para restaurar la función de la rodilla. Realizamos artroscopias de mínima invasión para reparar meniscos y ligamentos, así como reemplazos articulares (prótesis) para casos de desgaste severo.',
      symptoms: ['Dolor crónico que no cede con medicamentos', 'Desgaste articular severo visible en radiografías', 'Rotura confirmada de ligamento cruzado o menisco', 'Deformidad progresiva de la articulación'],
      whenToConsult: 'Cuando los tratamientos conservadores (medicamentos, fisioterapia, infiltraciones) ya no alivian el dolor y tu calidad de vida se ve severamente afectada.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/517667aca9370a50d7b8fdbcb259d5e5.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20cirug%C3%ADa%20de%20rodilla.'
    },
    {
      id: 'pie-tobillo',
      title: 'Dolor de Pie y Tobillo',
      description: 'Tratamiento especializado para afecciones complejas del pie y tobillo, incluyendo fascitis plantar, espolón calcáneo, esguinces crónicos, tendinitis de Aquiles y deformidades estructurales.',
      symptoms: ['Dolor agudo en el talón al dar los primeros pasos del día', 'Hinchazón crónica en el tobillo', 'Dolor en el arco del pie tras estar de pie', 'Dificultad para usar calzado normal'],
      whenToConsult: 'Si experimentas dolor persistente al caminar, hinchazón que no desaparece, o si has sufrido múltiples esguinces que han dejado tu tobillo inestable.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/6fa2ffd0776a48782d8521144dcd629a.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20dolor%20de%20pie%20y%20tobillo.'
    },
    {
      id: 'fracturas',
      title: 'Fracturas y Luxaciones',
      description: 'Manejo integral de huesos rotos y articulaciones dislocadas. Utilizamos técnicas de vanguardia y osteosíntesis para asegurar una alineación perfecta y una recuperación óptima, minimizando las secuelas a largo plazo.',
      symptoms: ['Dolor intenso e inmediato tras un impacto o caída', 'Deformidad visible en la extremidad o articulación', 'Incapacidad total para mover la zona afectada', 'Hinchazón rápida, hematomas o sangrado'],
      whenToConsult: 'Acude de inmediato a urgencias si sospechas de una fractura, especialmente si hay deformidad evidente, el hueso ha roto la piel o el dolor es incontrolable.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/523a2d743d3610aa6a1450f0f66283b9.png',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20Fracturas%20y%20luxaciones.'
    }
  ];

  const handleWhatsApp = (serviceName) => {
    const message = `Hola, quisiera agendar una cita para información sobre ${serviceName}.`;
    window.open(`https://wa.me/5213221016036?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleScrollToSection = (event, id) => {
    event.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      window.history.replaceState(null, '', `#${id}`);
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="es" />
        <title>Servicios Médicos | Doctor Calvario</title>
        <meta name="description" content="Especialidades en ortopedia y traumatología: Urgencias, lesiones deportivas, artroscopia, fracturas, inmovilizaciones, infiltraciones y más." />
        <link rel="alternate" hrefLang="en" href="/en/services" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow">
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block w-full max-w-4xl"
              >
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Servicios Médicos
                </h1>
                <p className="text-xl text-primary/80 max-w-2xl mx-auto font-medium mb-10">
                  Soluciones ortopédicas avanzadas para restaurar tu movilidad y eliminar el dolor.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <a href="https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold px-8 py-6 rounded-xl shadow-lg transition-all duration-300 hover:-translate-y-1">
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Agendar por WhatsApp
                    </Button>
                  </a>
                  <a href="tel:+523221016036" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white font-bold px-8 py-6 rounded-xl shadow-lg transition-all duration-300 hover:-translate-y-1">
                      <Phone className="w-5 h-5 mr-2" />
                      Llamar ahora
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Grid de Servicios Generales */}
          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {services.map((service, index) => (
                  <motion.div
                    key={index}
                    id={`servicio-${service.anchorId}-card`}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 border border-border flex flex-col h-full group"
                  >
                    <div className="w-16 h-16 bg-primary/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-secondary/10 transition-colors duration-300 border border-primary/10">
                      <service.icon className="w-8 h-8 text-secondary" />
                    </div>
                    <h3 className="text-2xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {service.title}
                    </h3>
                    <p className="text-primary/80 font-medium leading-relaxed mb-8 flex-grow">
                      {service.description}
                    </p>
                    
                    <div className="mt-auto flex flex-col gap-3 w-full">
                      {service.isEmergency ? (
                        <a href="tel:+523221016036" className="w-full">
                          <Button 
                            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                          >
                            <Phone className="w-5 h-5 mr-2" />
                            Llamar ahora
                          </Button>
                        </a>
                      ) : service.whatsappUrl ? (
                        <a href={service.whatsappUrl} target="_blank" rel="noopener noreferrer" className="w-full">
                          <Button 
                            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                          >
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Agendar Cita
                          </Button>
                        </a>
                      ) : (
                        <Button 
                          onClick={() => handleWhatsApp(service.title)}
                          className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                        >
                          <MessageCircle className="w-5 h-5 mr-2" />
                          Agendar Cita
                        </Button>
                      )}
                      
                      <a 
                        href={`#${service.anchorId}`}
                        onClick={(e) => handleScrollToSection(e, service.anchorId)}
                        className="w-full"
                      >
                        <Button 
                          className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                        >
                          Más información
                        </Button>
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Secciones Expandidas de Servicios */}
          <section className="py-24 relative bg-white/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-20">
                <h2 className="text-3xl md:text-5xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Especialidades Destacadas
                </h2>
                <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
              </div>

              <div className="space-y-32">
                {expandedServices.map((service, index) => (
                  <div 
                    key={service.id} 
                    id={service.id} 
                    className="scroll-mt-32"
                  >
                    <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                      
                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.7 }}
                        className={`relative ${index % 2 !== 0 ? 'lg:order-2' : ''}`}
                      >
                        <div className="absolute inset-0 bg-accent/20 rounded-[2.5rem] transform translate-x-4 translate-y-4"></div>
                        <img 
                          src={service.image} 
                          alt={service.title} 
                          className="relative rounded-[2.5rem] shadow-2xl object-cover aspect-[4/3] w-full border-8 border-white" 
                        />
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? 30 : -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.7 }}
                        className={`card-standard ${index % 2 !== 0 ? 'lg:order-1' : ''}`}
                      >
                        <h3 className="text-3xl md:text-4xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                          {service.title}
                        </h3>
                        <p className="text-lg text-primary/80 font-medium mb-8 leading-relaxed">
                          {service.description}
                        </p>
                        
                        <div className="mb-8">
                          <h4 className="text-xl font-bold text-primary mb-4 flex items-center">
                            <ActivitySquare className="w-6 h-6 mr-2 text-secondary" />
                            Síntomas Comunes
                          </h4>
                          <ul className="space-y-3">
                            {service.symptoms.map((symptom, i) => (
                              <li key={i} className="flex items-start">
                                <CheckCircle2 className="w-5 h-5 text-accent mr-3 flex-shrink-0 mt-0.5" />
                                <span className="text-primary/80 font-medium">{symptom}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-primary/5 rounded-2xl p-6 mb-8 border border-primary/10">
                          <h4 className="text-lg font-bold text-primary mb-2">¿Cuándo consultar?</h4>
                          <p className="text-primary/80 font-medium">{service.whenToConsult}</p>
                        </div>

                        <a href={service.waLink} target="_blank" rel="noopener noreferrer" className="inline-block w-full sm:w-auto">
                          <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-lg px-8 py-7 rounded-xl shadow-xl transition-all duration-300 hover:-translate-y-1">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Agendar Valoración
                          </Button>
                        </a>
                      </motion.div>

                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section - Segunda Opinión */}
          <section className="py-24 relative">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
              <div className="bg-primary rounded-[3rem] p-8 sm:p-12 md:p-20 shadow-2xl border-4 border-accent/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-secondary/20 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-accent/20 rounded-full blur-3xl"></div>
                
                <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 relative z-10" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Si tu caso es complicado o ya tuviste una Cirugía y quieres una 2da Opinión, agenda tu cita GRATIS.
                </h2>
                <a href="https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita" target="_blank" rel="noopener noreferrer" className="relative z-10 inline-block mt-8 w-full sm:w-auto">
                  <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-base sm:text-xl px-6 sm:px-10 py-6 sm:py-7 rounded-xl shadow-2xl shadow-secondary/30 transition-all duration-300 hover:scale-105 whitespace-normal h-auto">
                    <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" />
                    <span>Agendar por WhatsApp</span>
                  </Button>
                </a>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default ServiciosPage;