import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Bone, MessageCircle, CheckCircle2, AlertCircle, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const FracturasPage = () => {
  const fracturasList = [
    {
      id: 'fractura-tobillo',
      title: 'Fractura de Tobillo',
      description: 'Lesión en los huesos que forman la articulación del tobillo (tibia y peroné). Puede variar desde una fisura leve hasta una fractura compleja que requiere cirugía para restaurar la estabilidad.',
      causas: 'Torceduras severas, caídas, impactos directos durante deportes o accidentes automovilísticos.',
      sintomas: 'Dolor inmediato y punzante, hinchazón rápida, hematomas, sensibilidad al tacto, deformidad evidente y dificultad o incapacidad para caminar.',
      tratamiento: 'Dependiendo de la gravedad, puede tratarse con inmovilización (yeso o bota ortopédica) o cirugía para realinear los huesos con placas y tornillos (osteosíntesis).',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20tobillo.'
    },
    {
      id: 'fractura-muneca',
      title: 'Fractura de Muñeca',
      description: 'Rotura de uno o más huesos de la muñeca, frecuentemente el radio distal. Es una de las fracturas más comunes en todas las edades.',
      causas: 'Generalmente ocurre al intentar detener una caída apoyando la mano extendida.',
      sintomas: 'Dolor intenso que empeora al mover la mano, hinchazón, deformidad (la muñeca puede verse torcida), hematomas y rigidez en los dedos.',
      tratamiento: 'Reducción cerrada e inmovilización con yeso para fracturas simples. Las fracturas desplazadas o inestables requieren cirugía con placas de titanio.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20mu%C3%B1eca.'
    },
    {
      id: 'fractura-clavicula',
      title: 'Fractura de Clavícula',
      description: 'Rotura del hueso que conecta el esternón con el omóplato. Muy frecuente en personas activas y deportistas.',
      causas: 'Caídas sobre el hombro, impactos directos o caídas con el brazo extendido.',
      sintomas: 'Hombro caído hacia adelante y abajo, incapacidad para levantar el brazo, bulto visible sobre la clavícula, dolor agudo y crujido al intentar mover el hombro.',
      tratamiento: 'La mayoría sana con inmovilización (cabestrillo o vendaje en ocho). La cirugía se reserva para fracturas muy desplazadas o que acortan significativamente el hombro.',
      image: 'https://images.unsplash.com/photo-1696118541216-672bf6d371a7',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20clav%C3%ADcula.'
    },
    {
      id: 'fractura-humero',
      title: 'Fractura de Húmero',
      description: 'Rotura del hueso largo del brazo, desde el hombro hasta el codo. Puede ocurrir en la parte superior (proximal), en el medio (diáfisis) o cerca del codo (distal).',
      causas: 'Traumatismos directos, accidentes de tráfico o caídas en personas mayores con osteoporosis.',
      sintomas: 'Dolor severo, hinchazón, incapacidad para mover el brazo, deformidad visible y, en ocasiones, sensación de hormigueo en la mano si hay afectación nerviosa.',
      tratamiento: 'Inmovilización con férulas especiales o cirugía con clavos intramedulares o placas, dependiendo de la ubicación y el desplazamiento de la fractura.',
      image: 'https://images.unsplash.com/photo-1696118541216-672bf6d371a7',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20h%C3%BAmero.'
    },
    {
      id: 'fractura-femur',
      title: 'Fractura de Fémur',
      description: 'Rotura del hueso del muslo, el más largo y fuerte del cuerpo. Requiere una fuerza considerable para romperse en personas jóvenes.',
      causas: 'Accidentes automovilísticos de alta energía, caídas de gran altura o traumatismos severos.',
      sintomas: 'Dolor extremo, incapacidad total para apoyar la pierna, deformidad evidente (la pierna puede verse más corta o torcida) e hinchazón masiva.',
      tratamiento: 'Casi siempre requiere cirugía urgente, generalmente utilizando un clavo intramedular de titanio que se inserta por el centro del hueso para estabilizarlo.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20f%C3%A9mur.'
    },
    {
      id: 'fractura-vertebral',
      title: 'Fractura Vertebral',
      description: 'Colapso o rotura de los huesos de la columna vertebral. Pueden ser fracturas por compresión (comunes en osteoporosis) o fracturas por estallido (traumatismos graves).',
      causas: 'Osteoporosis (incluso por movimientos leves), accidentes de tráfico, caídas de altura o lesiones deportivas extremas.',
      sintomas: 'Dolor de espalda repentino y severo que empeora al estar de pie o caminar, pérdida de estatura, deformidad en la columna y, en casos graves, debilidad o entumecimiento en las piernas.',
      tratamiento: 'Reposo, corsés ortopédicos y medicamentos. En casos severos o dolor crónico, procedimientos mínimamente invasivos como vertebroplastia o cirugía de fijación espinal.',
      image: 'https://images.unsplash.com/photo-1584555684040-bad07f46a21f',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20vertebral.'
    },
    {
      id: 'fractura-antebrazo',
      title: 'Fractura de Antebrazo',
      description: 'Rotura del radio, el cúbito o ambos huesos del antebrazo. Es crucial restaurar la alineación exacta para mantener la capacidad de girar la mano.',
      causas: 'Impactos directos en el brazo o caídas apoyando la mano extendida.',
      sintomas: 'Dolor intenso, deformidad visible, hinchazón, incapacidad para rotar la palma de la mano hacia arriba o hacia abajo.',
      tratamiento: 'En adultos, la mayoría de las fracturas desplazadas de ambos huesos requieren cirugía con placas y tornillos para asegurar una recuperación funcional completa.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20antebrazo.'
    },
    {
      id: 'fractura-codo',
      title: 'Fractura de Codo',
      description: 'Lesión en la articulación donde se unen el húmero, el radio y el cúbito. Puede involucrar la punta del codo (olécranon) o las estructuras internas.',
      causas: 'Caídas directas sobre el codo flexionado o impactos fuertes.',
      sintomas: 'Dolor agudo, hinchazón rápida, incapacidad para doblar o estirar el brazo, y posible entumecimiento en los dedos si hay compresión nerviosa.',
      tratamiento: 'Las fracturas sin desplazamiento pueden tratarse con férulas. Las desplazadas requieren cirugía con alambres, clavos o placas para permitir una movilización temprana y evitar rigidez.',
      image: 'https://images.unsplash.com/photo-1696118541216-672bf6d371a7',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20codo.'
    },
    {
      id: 'fractura-rodilla',
      title: 'Fractura de Rodilla',
      description: 'Rotura de la rótula (patela) o de las porciones articulares del fémur o la tibia. Afecta directamente el mecanismo de extensión de la pierna.',
      causas: 'Impactos directos (como golpear el tablero en un accidente de auto) o caídas fuertes sobre la rodilla.',
      sintomas: 'Dolor intenso, hinchazón masiva (hemartrosis), incapacidad para levantar la pierna estirada y deformidad palpable en la rótula.',
      tratamiento: 'Inmovilización si los fragmentos no están separados. Cirugía (cerclaje o placas) si la fractura está desplazada, para restaurar la superficie articular y prevenir artrosis.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20rodilla.'
    },
    {
      id: 'fractura-tibia',
      title: 'Fractura de Tibia',
      description: 'Rotura del hueso principal de la espinilla. Al estar justo debajo de la piel, tiene un alto riesgo de ser una fractura expuesta (el hueso rompe la piel).',
      causas: 'Accidentes de motocicleta, lesiones deportivas de alto impacto o caídas severas.',
      sintomas: 'Dolor extremo, incapacidad para soportar peso, deformidad evidente en la pierna y posible hueso visible si es expuesta.',
      tratamiento: 'Frecuentemente tratada con cirugía mediante la inserción de un clavo intramedular o fijadores externos si hay daño severo en los tejidos blandos.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20tibia.'
    },
    {
      id: 'fractura-cadera',
      title: 'Fractura de Cadera',
      description: 'Rotura en la parte superior del fémur, cerca de la articulación de la pelvis. Es una emergencia médica, especialmente en adultos mayores.',
      causas: 'Caídas simples en personas con osteoporosis o traumatismos de alta energía en jóvenes.',
      sintomas: 'Dolor severo en la ingle o cadera, incapacidad para moverse o levantarse, y la pierna afectada suele verse más corta y girada hacia afuera.',
      tratamiento: 'Casi siempre requiere cirugía urgente (fijación con tornillos especiales o reemplazo parcial/total de cadera) para permitir que el paciente vuelva a caminar lo antes posible.',
      image: 'https://images.unsplash.com/photo-1696118528136-7ce44673d87d',
      waLink: 'https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20valoraci%C3%B3n%20con%20el%20Dr.%20Calvario%20por%20fractura%20de%20cadera.'
    }
  ];

  return (
    <WatermarkBackground>
      <Helmet>
        <title>Tipos de Fracturas | Doctor Calvario</title>
        <meta name="description" content="Información detallada sobre el diagnóstico y tratamiento de fracturas de tobillo, muñeca, cadera, fémur y más. Atención especializada en Puerto Vallarta." />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent" id="fracturas">
        <Header />

        {/* Ocultamos la sección completa con display: none, manteniendo los IDs intactos */}
        <main className="flex-grow" style={{ display: 'none' }}>
          {/* Hero Section */}
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block max-w-4xl"
              >
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Guía de Fracturas
                </h1>
                <p className="text-xl text-primary/80 font-medium mb-8">
                  Información clínica sobre los tipos de fracturas más comunes, sus síntomas y opciones de tratamiento especializado.
                </p>
                
                {/* Visual Index */}
                <div className="flex flex-wrap justify-center gap-3 mt-8">
                  {fracturasList.map((fractura) => (
                    <a 
                      key={fractura.id} 
                      href={`#${fractura.id}`}
                      className="px-4 py-2 bg-primary/5 hover:bg-primary hover:text-white text-primary font-bold rounded-full transition-colors duration-300 text-sm border border-primary/10"
                    >
                      {fractura.title.replace('Fractura de ', '').replace('Fractura ', '')}
                    </a>
                  ))}
                </div>
              </motion.div>
            </div>
          </section>

          {/* Fracturas List */}
          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="space-y-24">
                {fracturasList.map((fractura, index) => (
                  <div key={fractura.id} id={fractura.id} className="scroll-mt-32">
                    <div className={`grid grid-cols-1 lg:grid-cols-12 gap-12 items-center ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                      
                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.6 }}
                        className={`lg:col-span-5 ${index % 2 !== 0 ? 'lg:order-2' : ''}`}
                      >
                        <div className="relative rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
                          <div className="absolute inset-0 bg-primary/10 mix-blend-multiply z-10"></div>
                          <img 
                            src={fractura.image} 
                            alt={`Radiografía representativa de ${fractura.title}`} 
                            className="w-full h-full object-cover aspect-[4/5] filter grayscale contrast-125" 
                          />
                          <div className="absolute bottom-4 right-4 z-20 bg-white/90 backdrop-blur-sm p-3 rounded-xl shadow-lg">
                            <Bone className="w-8 h-8 text-primary" />
                          </div>
                        </div>
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? 30 : -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.6 }}
                        className={`lg:col-span-7 card-standard ${index % 2 !== 0 ? 'lg:order-1' : ''}`}
                      >
                        <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                          {fractura.title}
                        </h2>
                        
                        <div className="space-y-6 mb-8">
                          <div>
                            <p className="text-lg text-primary/80 font-medium leading-relaxed">
                              {fractura.description}
                            </p>
                          </div>

                          <div className="bg-primary/5 rounded-2xl p-6 border border-primary/10">
                            <h3 className="text-lg font-bold text-primary mb-2 flex items-center">
                              <AlertCircle className="w-5 h-5 mr-2 text-accent" />
                              Causas Principales
                            </h3>
                            <p className="text-primary/80 font-medium">{fractura.causas}</p>
                          </div>

                          <div>
                            <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
                              <CheckCircle2 className="w-5 h-5 mr-2 text-secondary" />
                              Síntomas
                            </h3>
                            <p className="text-primary/80 font-medium leading-relaxed">{fractura.sintomas}</p>
                          </div>

                          <div>
                            <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
                              <Activity className="w-5 h-5 mr-2 text-secondary" />
                              Tratamiento
                            </h3>
                            <p className="text-primary/80 font-medium leading-relaxed">{fractura.tratamiento}</p>
                          </div>
                        </div>

                        <a href={fractura.waLink} target="_blank" rel="noopener noreferrer" className="inline-block w-full sm:w-auto">
                          <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-lg px-8 py-6 rounded-xl shadow-xl transition-all duration-300 hover:-translate-y-1">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Agendar Valoración
                          </Button>
                        </a>
                      </motion.div>

                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default FracturasPage;