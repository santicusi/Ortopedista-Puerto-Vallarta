import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, MessageCircle, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import EnHeader from '@/components/EnHeader.jsx';
import EnFooter from '@/components/EnFooter.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const EnLocationPage = () => {
  const handleDirections = () => {
    window.open('https://maps.google.com/?q=Blvd.+Francisco+Medina+Ascencio+2735-9,+Zona+Hotelera+Nte.,+48333+Puerto+Vallarta,+Jal.', '_blank');
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="en" />
        <title>Location | Dr. Calvario</title>
        <meta name="description" content="Visit us at SANMARÉ Health-Care Group, Puerto Vallarta. Find our address and map." />
        <link rel="alternate" hrefLang="es" href="/ubicacion" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <EnHeader />

        <main className="flex-grow">
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div 
                initial={{ opacity: 0, y: 20 }} 
                animate={{ opacity: 1, y: 0 }} 
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block"
              >
                <h1 className="text-heading text-4xl md:text-5xl lg:text-6xl mb-4">
                  Location
                </h1>
                <p className="text-body text-xl max-w-2xl mx-auto">
                  First-class facilities for your comfort and speedy recovery.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                
                {/* Info Column */}
                <motion.div 
                  initial={{ opacity: 0, x: -20 }} 
                  animate={{ opacity: 1, x: 0 }} 
                  transition={{ duration: 0.6 }} 
                  className="space-y-10"
                >
                  <div className="card-standard">
                    <span className="inline-block py-1.5 px-4 rounded-full bg-primary/10 text-primary border border-primary/20 text-sm font-bold tracking-wider uppercase mb-6">
                      Main Headquarters
                    </span>
                    <h2 className="text-heading text-3xl md:text-4xl mb-4">
                      SANMARÉ Health-Care Group
                    </h2>
                    <p className="text-body text-lg">
                      Dr. Calvario provides consultations in the modern facilities of SANMARÉ, equipped with cutting-edge medical technology in the heart of Puerto Vallarta.
                    </p>
                  </div>

                  <div className="card-standard">
                    <div className="flex items-start gap-5 mb-8">
                      <div className="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center flex-shrink-0 border border-primary/20">
                        <MapPin className="w-7 h-7 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-heading text-2xl mb-3">Address</h3>
                        <p className="text-body text-lg">
                          Blvd. Francisco Medina Ascencio 2735-9<br />
                          Zona Hotelera, Zona Hotelera Nte.<br />
                          C.P. 48333 Puerto Vallarta, Jal.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button onClick={handleDirections} className="flex-1 bg-primary hover:bg-primary/90 text-white font-bold py-7 text-lg rounded-xl shadow-lg transition-all duration-300">
                      <Navigation className="w-5 h-5 mr-2" />
                      Get Directions
                    </Button>
                    <a href="https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment" target="_blank" rel="noopener noreferrer" className="flex-1">
                      <Button className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-7 text-lg rounded-xl shadow-lg transition-all duration-300">
                        <MessageCircle className="w-5 h-5 mr-2" />
                        WhatsApp
                      </Button>
                    </a>
                  </div>
                </motion.div>

                {/* Visuals Column */}
                <motion.div 
                  initial={{ opacity: 0, x: 20 }} 
                  animate={{ opacity: 1, x: 0 }} 
                  transition={{ duration: 0.6, delay: 0.2 }} 
                  className="space-y-8"
                >
                  <div className="rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white aspect-video relative">
                    <img src="https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/whatsapp-image-2026-03-24-at-19.31.38-nTZcX.jpeg" alt="SANMARÉ Health-Care Group Facilities" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/80 to-transparent flex items-end p-8">
                      <p className="text-white font-bold text-xl">First-class facilities</p>
                    </div>
                  </div>

                  <div className="card-standard h-[300px] flex flex-col items-center justify-center relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
                    <MapPin className="w-16 h-16 text-secondary mb-4 relative z-10" />
                    <p className="text-heading text-2xl relative z-10">
                      Interactive Map
                    </p>
                    <p className="text-body text-lg mt-2 relative z-10">
                      Puerto Vallarta, Jalisco
                    </p>
                    <Button onClick={handleDirections} variant="outline" className="mt-6 relative z-10 border-2 border-primary text-primary hover:bg-primary hover:text-white font-bold px-8 py-6 rounded-xl transition-all duration-300">
                      Open in Google Maps
                    </Button>
                  </div>
                </motion.div>

              </div>
            </div>
          </section>
        </main>

        <EnFooter />
      </div>
    </WatermarkBackground>
  );
};

export default EnLocationPage;