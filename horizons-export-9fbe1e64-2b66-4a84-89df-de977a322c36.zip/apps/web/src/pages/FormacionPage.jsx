import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Anchor, MapPin, Calendar, Award } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const FormacionPage = () => {
  const education = [
    {
      institution: 'Escuela Médico Naval',
      period: 'Formación Base',
      location: 'México',
      logo: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/85003683ad89ccb110a3d5d0d1f7b811.png',
      description: 'Formación integral como Médico Cirujano Naval, combinando la excelencia académica médica con la disciplina y valores de la Armada de México.',
      highlights: ['Médico Cirujano Naval', 'Formación militar y médica de alto rendimiento']
    },
    {
      institution: 'Centro Médico Naval',
      period: 'Especialización',
      location: 'Ciudad de México',
      logo: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/a490feaa577db411c35b66e7b9ad3274.jpg',
      description: 'Residencia médica y especialización en Traumatología y Ortopedia en uno de los hospitales de más alto nivel del país.',
      highlights: ['Especialidad en Traumatología y Ortopedia', 'Manejo de trauma complejo'],
      isDarkLogo: false
    },
    {
      institution: 'USN Surface Warfare Medical Institute',
      period: 'Entrenamiento Internacional',
      location: 'Estados Unidos',
      logo: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/dd461b86ea83e3b7e51c290eaa0f3b62.jpg',
      description: 'Entrenamiento especializado en medicina operativa y manejo de trauma en entornos de alta exigencia.',
      highlights: ['Medicina Operativa', 'Trauma avanzado']
    },
    {
      institution: 'Navy Medical Center San Diego',
      period: 'Rotación Internacional',
      location: 'San Diego, CA, EE.UU.',
      logo: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/a82bf2697c0a5f92e6085e684f05f5dc.png',
      description: 'Experiencia clínica en uno de los centros médicos militares más grandes y avanzados del mundo, perfeccionando técnicas ortopédicas.',
      highlights: ['Técnicas quirúrgicas de vanguardia', 'Ortopedia avanzada']
    }
  ];

  const trainings = [
    {
      title: 'Ortopedia Pediátrica',
      institution: 'Shriners Hospital for Children Mexico'
    },
    {
      title: 'Tumores Óseos',
      institution: 'Instituto Nacional de Cancerología'
    },
    {
      title: 'Cirugía de Pie y Tobillo / Hombro / Lesiones Deportivas',
      institution: 'Hospital Naval de Veracruz'
    },
    {
      title: 'Artroscopia / Reemplazo Articular / Cirugía de Mano / Cirugía de Columna',
      institution: 'Centro Médico Naval'
    },
    {
      title: 'Cirugía de Mano / Trauma',
      institution: 'Hospital Obregón'
    }
  ];

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="es" />
        <title>Formación Académica | Doctor Calvario</title>
        <meta name="description" content="Conoce la formación académica y naval del Dr. Hugo Adrián Sánchez Calvario en instituciones de prestigio nacional e internacional." />
        <link rel="alternate" hrefLang="en" href="/en/training" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow">
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block"
              >
                <h1 className="text-heading text-4xl md:text-5xl lg:text-6xl mb-4">
                  Formación Académica
                </h1>
                <p className="text-body text-xl max-w-2xl mx-auto">
                  Preparación de excelencia en instituciones médicas y navales de prestigio internacional.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-16 relative">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="space-y-12">
                {education.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-100px" }}
                    transition={{ duration: 0.6 }}
                    className="card-standard border-l-8 border-l-secondary relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity duration-300">
                      <Anchor className="w-40 h-40 text-primary" />
                    </div>
                    
                    <div className="relative z-10">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-8 mb-6">
                        <div className="flex-1">
                          <h2 className="text-heading text-2xl md:text-3xl mb-4">
                            {item.institution}
                          </h2>
                          <div className="flex flex-wrap items-center gap-4 text-sm font-bold text-primary/70 mb-4">
                            <span className="flex items-center gap-2 bg-primary/5 px-4 py-2 rounded-full border border-primary/10">
                              <Calendar className="w-4 h-4 text-secondary" />
                              {item.period}
                            </span>
                            <span className="flex items-center gap-2 bg-primary/5 px-4 py-2 rounded-full border border-primary/10">
                              <MapPin className="w-4 h-4 text-secondary" />
                              {item.location}
                            </span>
                          </div>
                          <p className="text-body text-lg max-w-3xl">
                            {item.description}
                          </p>
                        </div>
                        <div className={`hidden md:flex w-32 h-32 md:w-40 md:h-40 rounded-2xl items-center justify-center flex-shrink-0 border border-border shadow-sm overflow-hidden p-3 ${item.isDarkLogo ? 'bg-black' : 'bg-white'}`}>
                          <img 
                            src={item.logo} 
                            alt={`Logo ${item.institution}`} 
                            className={`w-full h-full object-contain ${item.isDarkLogo ? 'mix-blend-screen' : ''}`} 
                          />
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-bold text-primary uppercase tracking-wider mb-4">Puntos Destacados</h4>
                        <div className="flex flex-wrap gap-3">
                          {item.highlights.map((highlight, i) => (
                            <span key={i} className="inline-flex items-center px-4 py-2 rounded-xl bg-white border-2 border-border text-primary font-bold text-sm shadow-sm">
                              <span className="w-2 h-2 rounded-full bg-accent mr-2"></span>
                              {highlight}
                           </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Entrenamientos Formativos Section */}
          <section className="py-24 relative bg-white/50">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h2 className="text-heading text-3xl md:text-4xl mb-4">
                  Entrenamientos Formativos
                </h2>
                <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {trainings.map((training, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-2xl p-6 md:p-8 shadow-lg border border-border flex flex-col md:flex-row md:items-center gap-4 md:gap-8 hover:shadow-xl transition-shadow"
                  >
                    <div className="w-12 h-12 bg-primary/5 rounded-full flex items-center justify-center flex-shrink-0">
                      <Award className="w-6 h-6 text-secondary" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-primary mb-1">
                        {training.title}
                      </h3>
                      <p className="text-primary/70 font-medium flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-accent" />
                        {training.institution}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default FormacionPage;