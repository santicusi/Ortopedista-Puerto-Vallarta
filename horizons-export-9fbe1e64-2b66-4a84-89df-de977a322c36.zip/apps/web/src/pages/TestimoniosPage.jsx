import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const TestimoniosPage = () => {
  return (
    <WatermarkBackground>
      <Helmet>
        <title>Testimonios | Doctor Calvario</title>
        <meta name="description" content="Experiencias y testimonios de pacientes del Dr. Hugo Adrián Sánchez Calvario." />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow hidden" style={{ display: 'none' }}>
          {/* Testimonials content is temporarily hidden as requested */}
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <div className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Testimonios
                </h1>
                <p className="text-xl text-primary/80 max-w-2xl mx-auto font-medium">
                  Experiencias de pacientes.
                </p>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default TestimoniosPage;