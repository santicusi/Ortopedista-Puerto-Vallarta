import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const PadecimientosPage = () => {
  useEffect(() => {
    const handleGlobalClick = (e) => {
      const target = e.target.closest('a, button');
      if (!target) return;

      const href = target.getAttribute('href') || '';
      const isWhatsApp = href.includes('wa.me') || href.includes('whatsapp');
      const text = target.textContent.toLowerCase();
      const isContactCTA = text.includes('agendar') || text.includes('llamar') || text.includes('contacto');

      if (isWhatsApp || isContactCTA) {
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'conversion', {
            'send_to': 'AW-17964727570/6hAZCOOf1fsbEJL6n_ZC',
            'value': 1.0,
            'currency': 'COP'
          });
        }
      }
    };

    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  const padecimientos = [
    { id: 'padecimiento-esguinces', title: 'Esguinces', description: 'Tratamiento especializado para desgarros o estiramientos de ligamentos. Recupera la estabilidad de tus articulaciones con un manejo adecuado y rehabilitación temprana.' },
    { id: 'padecimiento-meniscos', title: 'Lesiones de los meniscos', description: 'Diagnóstico y tratamiento de desgarros meniscales. Opciones conservadoras y quirúrgicas (artroscopia) para aliviar el dolor y restaurar la función de tu rodilla.' },
    { id: 'padecimiento-ligamento-cruzado', title: 'Lesión de ligamento cruzado', description: 'Manejo integral de rupturas del LCA. Reconstrucción anatómica y protocolos de rehabilitación diseñados para que regreses a tu nivel deportivo previo.' },
    { id: 'padecimiento-lesiones-de-hombro', title: 'Lesiones de hombro', description: 'Atención experta para luxaciones, tendinitis y desgarros del manguito rotador. Recupera la movilidad y fuerza de tu hombro sin dolor.' },
    { id: 'padecimiento-lesiones-en-el-gimnasio', title: 'Lesiones en el gimnasio', description: 'Evaluación de sobrecargas, desgarros musculares y lesiones articulares por levantamiento de pesas. Optimiza tu técnica y sana de forma segura.' },
    { id: 'padecimiento-prevencion-deportiva', title: 'Prevención deportiva', description: 'Evaluaciones biomecánicas y programas personalizados para identificar factores de riesgo y evitar lesiones durante tu práctica deportiva.' },
    { id: 'padecimiento-prevencion-en-el-gym', title: 'Prevención en el gym', description: 'Asesoría médica para adaptar tus rutinas de entrenamiento, protegiendo tus articulaciones y maximizando tus resultados sin riesgo de lesión.' },
    { id: 'padecimiento-lesiones-de-codo', title: 'Lesiones de codo', description: 'Tratamiento para codo de tenista, codo de golfista y otras afecciones. Alivio del dolor y restauración de la fuerza de agarre.' },
    { id: 'padecimiento-fractura-de-antebrazo', title: 'Fractura de antebrazo', description: 'Reducción y estabilización de fracturas de radio y cúbito. Uso de técnicas avanzadas para asegurar una consolidación ósea perfecta.' },
    { id: 'padecimiento-fractura-de-muneca', title: 'Fractura de muñeca', description: 'Manejo especializado de fracturas del extremo distal del radio. Preservamos la movilidad fina y la fuerza de tu mano con tratamientos precisos.' },
    { id: 'padecimiento-fractura-de-humero', title: 'Fractura de húmero', description: 'Tratamiento conservador o quirúrgico para fracturas del brazo. Enfoque en la recuperación funcional temprana y control del dolor.' },
    { id: 'padecimiento-fractura-de-femur', title: 'Fractura de fémur', description: 'Atención de urgencia y resolución quirúrgica con osteosíntesis de vanguardia para fracturas del hueso más grande del cuerpo, permitiendo una movilización rápida.' },
    { id: 'padecimiento-fractura-de-la-mano', title: 'Fractura de la mano', description: 'Cuidado meticuloso de fracturas en metacarpianos y falanges. Restauramos la anatomía exacta para garantizar la destreza y función de tu mano.' },
    { id: 'padecimiento-fractura-de-tibia', title: 'Fractura de tibia', description: 'Estabilización experta de fracturas de la pierna. Utilizamos clavos centro medulares o placas para una recuperación segura y efectiva.' }
  ];

  const handleScrollToSection = (event, id) => {
    event.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      window.history.replaceState(null, '', `#${id}`);
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="es" />
        <title>Guía de Padecimientos | Doctor Calvario</title>
        <meta name="description" content="Conoce los padecimientos ortopédicos más comunes: esguinces, lesiones de meniscos, fracturas y más. Agenda tu cita para un diagnóstico preciso." />
        <link rel="alternate" hrefLang="en" href="/en/conditions" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow">
          <section id="padecimientos" className="py-24 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Guía de padecimientos
                </h1>
                <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
              </div>

              {/* Botones de navegación rápida */}
              <div className="flex flex-wrap justify-center gap-3 mb-20">
                {padecimientos.map((pad) => (
                  <Button
                    key={`btn-${pad.id}`}
                    variant="outline"
                    onClick={(e) => handleScrollToSection(e, pad.id)}
                    className="bg-white hover:bg-primary/5 text-primary border-primary/20 font-medium rounded-full px-6 py-2 h-auto whitespace-normal text-center shadow-sm transition-all duration-200 hover:-translate-y-0.5"
                  >
                    {pad.title}
                  </Button>
                ))}
              </div>

              {/* Tarjetas de padecimientos */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {padecimientos.map((pad, index) => (
                  <motion.div
                    key={pad.id}
                    id={pad.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: (index % 3) * 0.1 }}
                    className="bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 border border-border flex flex-col h-full scroll-mt-32 group"
                  >
                    <h3 className="text-2xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {pad.title}
                    </h3>
                    <p className="text-primary/80 font-medium leading-relaxed mb-8 flex-grow">
                      {pad.description}
                    </p>
                    <div className="mt-auto flex flex-col gap-3 w-full">
                      <a href={`https://wa.me/5213221016036?text=Hola%2C%20quiero%20agendar%20una%20cita%20por%20${encodeURIComponent(pad.title)}.`} target="_blank" rel="noopener noreferrer" className="w-full">
                        <Button className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300">
                          <MessageCircle className="w-5 h-5 mr-2" />
                          WhatsApp
                        </Button>
                      </a>
                      <a href="tel:+523221016036" className="w-full">
                        <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300">
                          <Phone className="w-5 h-5 mr-2" />
                          Llamar ahora
                        </Button>
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default PadecimientosPage;