import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Activity, Scissors, ActivitySquare, MessageCircle, ShieldPlus, PersonStanding, Phone, CheckCircle2, Ligature as Bandage, Syringe, Bone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import EnHeader from '@/components/EnHeader.jsx';
import EnFooter from '@/components/EnFooter.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const EnServicesPage = () => {
  useEffect(() => {
    const handleGlobalClick = (e) => {
      const target = e.target.closest('a, button');
      if (!target) return;

      const href = target.getAttribute('href') || '';
      const isWhatsApp = href.includes('wa.me') || href.includes('whatsapp');
      const text = target.textContent.toLowerCase();
      const isContactCTA = text.includes('book') || text.includes('call') || text.includes('contact');

      if (isWhatsApp || isContactCTA) {
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'conversion', {
            'send_to': 'AW-17964727570/6hAZCOOf1fsbEJL6n_ZC',
            'value': 1.0,
            'currency': 'COP'
          });
        }
      }
    };

    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  const services = [
    {
      icon: ShieldPlus,
      title: '24H Emergencies',
      description: 'Immediate and specialized medical care for acute musculoskeletal injuries. We are available 24/7.',
      isEmergency: true,
      anchorId: 'emergencies'
    },
    {
      icon: Activity,
      title: 'Back and Neck Pain',
      description: 'Comprehensive evaluation of the spine to treat lower back pain, neck pain, herniated discs, and sciatica.',
      anchorId: 'back-neck'
    },
    {
      icon: ActivitySquare,
      title: 'Knee Pain',
      description: 'Accurate diagnosis of the causes of knee pain, including cartilage wear, meniscus, and ligament injuries.',
      anchorId: 'knees'
    },
    {
      icon: Scissors,
      title: 'Knee and Hip Surgery',
      description: 'Advanced surgical interventions to restore knee function, including arthroscopies and joint replacements.',
      anchorId: 'knee-surgery'
    },
    {
      icon: PersonStanding,
      title: 'Foot and Ankle Pain',
      description: 'Specialized treatment for complex foot and ankle conditions, including plantar fasciitis and chronic sprains.',
      anchorId: 'foot-ankle'
    },
    {
      icon: Bandage,
      title: 'Immobilizations',
      description: 'Professional application of casts, splints, and specialized bandages to stabilize injuries and promote proper recovery.',
      anchorId: 'immobilizations',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment%20for%20Immobilizations'
    },
    {
      icon: Syringe,
      title: 'Infiltrations',
      description: 'Minimally invasive treatment to relieve severe joint pain and reduce inflammation quickly and effectively.',
      anchorId: 'infiltrations',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment%20for%20Infiltrations'
    },
    {
      icon: Activity,
      title: 'Back Pain',
      description: 'Comprehensive management of lumbar and cervical pain through conservative approaches and advanced therapies to improve your quality of life.',
      anchorId: 'back-pain',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment%20for%20Back%20pain'
    },
    {
      icon: Bone,
      title: 'Fractures and Dislocations',
      description: 'Comprehensive management of broken bones and dislocated joints. We use cutting-edge techniques and osteosynthesis.',
      anchorId: 'fractures',
      whatsappUrl: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment%20for%20Fractures%20and%20Dislocations.'
    }
  ];

  const expandedServices = [
    {
      id: 'emergencies',
      title: '24H Emergencies',
      description: 'Immediate and specialized medical care for acute musculoskeletal injuries. We are available 24/7 for stabilization, imaging diagnosis, and definitive treatment, whether conservative or surgical.',
      symptoms: ['Unbearable pain after trauma', 'Obvious deformity in a limb', 'Total inability to move a joint', 'Rapid and severe swelling with bruising'],
      whenToConsult: 'Seek immediate care if you suffer an accident, severe fall, or sports injury that prevents you from continuing your activities, causes intense pain, or if you suspect a fracture.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/0b03aeef46954214a782588e1c6a2464.png',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20emergency%20assessment%20with%20Dr.%20Calvario.'
    },
    {
      id: 'back-neck',
      title: 'Back and Neck Pain',
      description: 'Comprehensive evaluation of the spine to treat lower back pain, neck pain, herniated discs, and sciatica. Our approach seeks to relieve pain, reduce inflammation in affected nerves, and restore spinal biomechanics.',
      symptoms: ['Sharp or dull pain in the lumbar or cervical area', 'Pain radiating to the arms or legs (sciatica)', 'Tingling, numbness, or weakness', 'Muscle stiffness that limits movement'],
      whenToConsult: 'When back pain lasts more than a few weeks, does not improve with rest, radiates to the extremities, or is accompanied by muscle weakness or loss of sensation.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/666f0546ce880baa7462eda7b17d66b6.png',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20assessment%20with%20Dr.%20Calvario%20for%20back%20and%20neck%20pain.'
    },
    {
      id: 'knees',
      title: 'Knee Pain',
      description: 'Accurate diagnosis of the causes of knee pain, including cartilage wear (osteoarthritis), meniscus injuries, tendinitis, and ligament problems. We offer treatments ranging from infiltrations to rehabilitation.',
      symptoms: ['Pain when going up or down stairs', 'Clicking or locking sensation in the joint', 'Morning swelling and stiffness', 'Instability or feeling that the knee "gives way"'],
      whenToConsult: 'If the pain interferes with your daily activities, you notice persistent swelling, cannot fully extend your leg, or feel instability when walking.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/6dbf8f83340ad6ab8f81a65b1beba240.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20assessment%20with%20Dr.%20Calvario%20for%20knee%20pain.'
    },
    {
      id: 'knee-surgery',
      title: 'Knee and Hip Surgery',
      description: 'Advanced surgical interventions to restore knee function. We perform minimally invasive arthroscopies to repair menisci and ligaments, as well as joint replacements (prostheses) for cases of severe wear.',
      symptoms: ['Chronic pain that does not respond to medication', 'Severe joint wear visible on X-rays', 'Confirmed rupture of cruciate ligament or meniscus', 'Progressive joint deformity'],
      whenToConsult: 'When conservative treatments (medication, physical therapy, infiltrations) no longer relieve pain and your quality of life is severely affected.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/517667aca9370a50d7b8fdbcb259d5e5.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20assessment%20with%20Dr.%20Calvario%20for%20knee%20surgery.'
    },
    {
      id: 'foot-ankle',
      title: 'Foot and Ankle Pain',
      description: 'Specialized treatment for complex foot and ankle conditions, including plantar fasciitis, heel spurs, chronic sprains, Achilles tendinitis, and structural deformities.',
      symptoms: ['Sharp pain in the heel when taking the first steps of the day', 'Chronic swelling in the ankle', 'Pain in the arch of the foot after standing', 'Difficulty wearing normal footwear'],
      whenToConsult: 'If you experience persistent pain when walking, swelling that does not go away, or if you have suffered multiple sprains that have left your ankle unstable.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/6fa2ffd0776a48782d8521144dcd629a.jpg',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20assessment%20with%20Dr.%20Calvario%20for%20foot%20and%20ankle%20pain.'
    },
    {
      id: 'fractures',
      title: 'Fractures and Dislocations',
      description: 'Comprehensive management of broken bones and dislocated joints. We use cutting-edge techniques and osteosynthesis to ensure perfect alignment and optimal recovery, minimizing long-term sequelae.',
      symptoms: ['Intense and immediate pain after an impact or fall', 'Visible deformity in the limb or joint', 'Total inability to move the affected area', 'Rapid swelling, bruising, or bleeding'],
      whenToConsult: 'Go immediately to the emergency room if you suspect a fracture, especially if there is obvious deformity, the bone has broken the skin, or the pain is uncontrollable.',
      image: 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/523a2d743d3610aa6a1450f0f66283b9.png',
      waLink: 'https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20assessment%20with%20Dr.%20Calvario%20for%20Fractures%20and%20dislocations.'
    }
  ];

  const handleWhatsApp = (serviceName) => {
    const message = `Hello, I would like to schedule an appointment for information about ${serviceName}.`;
    window.open(`https://wa.me/5213221016036?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleScrollToSection = (event, id) => {
    event.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      window.history.replaceState(null, '', `#${id}`);
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="en" />
        <title>Medical Services | Doctor Calvario</title>
        <meta name="description" content="Specialties in orthopedics and traumatology: Emergencies, sports injuries, arthroscopy, fractures, immobilizations, infiltrations, and more." />
        <link rel="alternate" hrefLang="es" href="/servicios" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <EnHeader />

        <main className="flex-grow">
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block w-full max-w-4xl"
              >
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Medical Services
                </h1>
                <p className="text-xl text-primary/80 max-w-2xl mx-auto font-medium mb-10">
                  Advanced orthopedic solutions to restore your mobility and eliminate pain.
                </p>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <a href="https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold px-8 py-6 rounded-xl shadow-lg transition-all duration-300 hover:-translate-y-1">
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Book via WhatsApp
                    </Button>
                  </a>
                  <a href="tel:+523221016036" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white font-bold px-8 py-6 rounded-xl shadow-lg transition-all duration-300 hover:-translate-y-1">
                      <Phone className="w-5 h-5 mr-2" />
                      Call now
                    </Button>
                  </a>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Grid de Servicios Generales */}
          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {services.map((service, index) => (
                  <motion.div
                    key={index}
                    id={`servicio-${service.anchorId}-card`}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 border border-border flex flex-col h-full group"
                  >
                    <div className="w-16 h-16 bg-primary/5 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-secondary/10 transition-colors duration-300 border border-primary/10">
                      <service.icon className="w-8 h-8 text-secondary" />
                    </div>
                    <h3 className="text-2xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {service.title}
                    </h3>
                    <p className="text-primary/80 font-medium leading-relaxed mb-8 flex-grow">
                      {service.description}
                    </p>
                    
                    <div className="mt-auto flex flex-col gap-3 w-full">
                      {service.isEmergency ? (
                        <a href="tel:+523221016036" className="w-full">
                          <Button 
                            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                          >
                            <Phone className="w-5 h-5 mr-2" />
                            Call now
                          </Button>
                        </a>
                      ) : service.whatsappUrl ? (
                        <a href={service.whatsappUrl} target="_blank" rel="noopener noreferrer" className="w-full">
                          <Button 
                            className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                          >
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Book Appointment
                          </Button>
                        </a>
                      ) : (
                        <Button 
                          onClick={() => handleWhatsApp(service.title)}
                          className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                        >
                          <MessageCircle className="w-5 h-5 mr-2" />
                          Book Appointment
                        </Button>
                      )}
                      
                      <a 
                        href={`#${service.anchorId}`}
                        onClick={(e) => handleScrollToSection(e, service.anchorId)}
                        className="w-full"
                      >
                        <Button 
                          className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300"
                        >
                          More information
                        </Button>
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Secciones Expandidas de Servicios */}
          <section className="py-24 relative bg-white/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-20">
                <h2 className="text-3xl md:text-5xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Featured Specialties
                </h2>
                <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
              </div>

              <div className="space-y-32">
                {expandedServices.map((service, index) => (
                  <div 
                    key={service.id} 
                    id={service.id} 
                    className="scroll-mt-32"
                  >
                    <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                      
                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.7 }}
                        className={`relative ${index % 2 !== 0 ? 'lg:order-2' : ''}`}
                      >
                        <div className="absolute inset-0 bg-accent/20 rounded-[2.5rem] transform translate-x-4 translate-y-4"></div>
                        <img 
                          src={service.image} 
                          alt={service.title} 
                          className="relative rounded-[2.5rem] shadow-2xl object-cover aspect-[4/3] w-full border-8 border-white" 
                        />
                      </motion.div>

                      <motion.div 
                        initial={{ opacity: 0, x: index % 2 === 0 ? 30 : -30 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true, margin: "-100px" }}
                        transition={{ duration: 0.7 }}
                        className={`card-standard ${index % 2 !== 0 ? 'lg:order-1' : ''}`}
                      >
                        <h3 className="text-3xl md:text-4xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                          {service.title}
                        </h3>
                        <p className="text-lg text-primary/80 font-medium mb-8 leading-relaxed">
                          {service.description}
                        </p>
                        
                        <div className="mb-8">
                          <h4 className="text-xl font-bold text-primary mb-4 flex items-center">
                            <ActivitySquare className="w-6 h-6 mr-2 text-secondary" />
                            Common Symptoms
                          </h4>
                          <ul className="space-y-3">
                            {service.symptoms.map((symptom, i) => (
                              <li key={i} className="flex items-start">
                                <CheckCircle2 className="w-5 h-5 text-accent mr-3 flex-shrink-0 mt-0.5" />
                                <span className="text-primary/80 font-medium">{symptom}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-primary/5 rounded-2xl p-6 mb-8 border border-primary/10">
                          <h4 className="text-lg font-bold text-primary mb-2">When to consult?</h4>
                          <p className="text-primary/80 font-medium">{service.whenToConsult}</p>
                        </div>

                        <a href={service.waLink} target="_blank" rel="noopener noreferrer" className="inline-block w-full sm:w-auto">
                          <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-lg px-8 py-7 rounded-xl shadow-xl transition-all duration-300 hover:-translate-y-1">
                            <MessageCircle className="w-5 h-5 mr-2" />
                            Schedule Assessment
                          </Button>
                        </a>
                      </motion.div>

                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* CTA Section - Segunda Opinión */}
          <section className="py-24 relative">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
              <div className="bg-primary rounded-[3rem] p-8 sm:p-12 md:p-20 shadow-2xl border-4 border-accent/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-secondary/20 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-accent/20 rounded-full blur-3xl"></div>
                
                <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-6 relative z-10" style={{ fontFamily: 'Playfair Display, serif' }}>
                  If your case is complicated or you already had Surgery and want a 2nd Opinion, schedule your FREE appointment.
                </h2>
                <a href="https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment" target="_blank" rel="noopener noreferrer" className="relative z-10 inline-block mt-8 w-full sm:w-auto">
                  <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-base sm:text-xl px-6 sm:px-10 py-6 sm:py-7 rounded-xl shadow-2xl shadow-secondary/30 transition-all duration-300 hover:scale-105 whitespace-normal h-auto">
                    <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" />
                    <span>Book via WhatsApp</span>
                  </Button>
                </a>
              </div>
            </div>
          </section>
        </main>

        <EnFooter />
      </div>
    </WatermarkBackground>
  );
};

export default EnServicesPage;