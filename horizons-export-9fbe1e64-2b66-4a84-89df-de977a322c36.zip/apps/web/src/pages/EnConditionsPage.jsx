import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MessageCircle, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import EnHeader from '@/components/EnHeader.jsx';
import EnFooter from '@/components/EnFooter.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const EnConditionsPage = () => {
  useEffect(() => {
    const handleGlobalClick = (e) => {
      const target = e.target.closest('a, button');
      if (!target) return;

      const href = target.getAttribute('href') || '';
      const isWhatsApp = href.includes('wa.me') || href.includes('whatsapp');
      const text = target.textContent.toLowerCase();
      const isContactCTA = text.includes('book') || text.includes('call') || text.includes('contact');

      if (isWhatsApp || isContactCTA) {
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'conversion', {
            'send_to': 'AW-17964727570/6hAZCOOf1fsbEJL6n_ZC',
            'value': 1.0,
            'currency': 'COP'
          });
        }
      }
    };

    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  const padecimientos = [
    { id: 'condition-sprains', title: 'Sprains', description: 'Specialized treatment for ligament tears or stretching. Regain joint stability with proper management and early rehabilitation.' },
    { id: 'condition-meniscus', title: 'Meniscus Injuries', description: 'Diagnosis and treatment of meniscal tears. Conservative and surgical options (arthroscopy) to relieve pain and restore knee function.' },
    { id: 'condition-cruciate-ligament', title: 'Cruciate Ligament Injury', description: 'Comprehensive management of ACL ruptures. Anatomic reconstruction and rehabilitation protocols designed to return you to your previous sports level.' },
    { id: 'condition-shoulder-injuries', title: 'Shoulder Injuries', description: 'Expert care for dislocations, tendinitis, and rotator cuff tears. Regain mobility and strength in your shoulder without pain.' },
    { id: 'condition-gym-injuries', title: 'Gym Injuries', description: 'Evaluation of overloads, muscle tears, and joint injuries from weightlifting. Optimize your technique and heal safely.' },
    { id: 'condition-sports-prevention', title: 'Sports Prevention', description: 'Biomechanical evaluations and personalized programs to identify risk factors and prevent injuries during your sports practice.' },
    { id: 'condition-gym-prevention', title: 'Gym Prevention', description: 'Medical advice to adapt your training routines, protecting your joints and maximizing your results without risk of injury.' },
    { id: 'condition-elbow-injuries', title: 'Elbow Injuries', description: 'Treatment for tennis elbow, golfer\'s elbow, and other conditions. Pain relief and restoration of grip strength.' },
    { id: 'condition-forearm-fracture', title: 'Forearm Fracture', description: 'Reduction and stabilization of radius and ulna fractures. Use of advanced techniques to ensure perfect bone consolidation.' },
    { id: 'condition-wrist-fracture', title: 'Wrist Fracture', description: 'Specialized management of distal radius fractures. We preserve the fine mobility and strength of your hand with precise treatments.' },
    { id: 'condition-humerus-fracture', title: 'Humerus Fracture', description: 'Conservative or surgical treatment for arm fractures. Focus on early functional recovery and pain control.' },
    { id: 'condition-femur-fracture', title: 'Femur Fracture', description: 'Emergency care and surgical resolution with cutting-edge osteosynthesis for fractures of the largest bone in the body, allowing rapid mobilization.' },
    { id: 'condition-hand-fracture', title: 'Hand Fracture', description: 'Meticulous care of fractures in metacarpals and phalanges. We restore exact anatomy to ensure the dexterity and function of your hand.' },
    { id: 'condition-tibia-fracture', title: 'Tibia Fracture', description: 'Expert stabilization of leg fractures. We use intramedullary nails or plates for a safe and effective recovery.' }
  ];

  const handleScrollToSection = (event, id) => {
    event.preventDefault();
    const el = document.getElementById(id);
    if (el) {
      window.history.replaceState(null, '', `#${id}`);
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="en" />
        <title>Conditions Guide | Doctor Calvario</title>
        <meta name="description" content="Learn about the most common orthopedic conditions: sprains, meniscus injuries, fractures, and more. Book your appointment for an accurate diagnosis." />
        <link rel="alternate" hrefLang="es" href="/padecimientos" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <EnHeader />

        <main className="flex-grow">
          <section id="conditions" className="py-24 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                  Conditions Guide
                </h1>
                <div className="w-24 h-1.5 bg-accent mx-auto rounded-full"></div>
              </div>

              {/* Botones de navegación rápida */}
              <div className="flex flex-wrap justify-center gap-3 mb-20">
                {padecimientos.map((pad) => (
                  <Button
                    key={`btn-${pad.id}`}
                    variant="outline"
                    onClick={(e) => handleScrollToSection(e, pad.id)}
                    className="bg-white hover:bg-primary/5 text-primary border-primary/20 font-medium rounded-full px-6 py-2 h-auto whitespace-normal text-center shadow-sm transition-all duration-200 hover:-translate-y-0.5"
                  >
                    {pad.title}
                  </Button>
                ))}
              </div>

              {/* Tarjetas de padecimientos */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {padecimientos.map((pad, index) => (
                  <motion.div
                    key={pad.id}
                    id={pad.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: (index % 3) * 0.1 }}
                    className="bg-white rounded-3xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 border border-border flex flex-col h-full scroll-mt-32 group"
                  >
                    <h3 className="text-2xl font-bold text-primary mb-4" style={{ fontFamily: 'Playfair Display, serif' }}>
                      {pad.title}
                    </h3>
                    <p className="text-primary/80 font-medium leading-relaxed mb-8 flex-grow">
                      {pad.description}
                    </p>
                    <div className="mt-auto flex flex-col gap-3 w-full">
                      <a href={`https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment%20for%20${encodeURIComponent(pad.title)}.`} target="_blank" rel="noopener noreferrer" className="w-full">
                        <Button className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300">
                          <MessageCircle className="w-5 h-5 mr-2" />
                          WhatsApp
                        </Button>
                      </a>
                      <a href="tel:+523221016036" className="w-full">
                        <Button className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-6 rounded-xl shadow-md transition-all duration-300">
                          <Phone className="w-5 h-5 mr-2" />
                          Call now
                        </Button>
                      </a>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        </main>

        <EnFooter />
      </div>
    </WatermarkBackground>
  );
};

export default EnConditionsPage;