import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MessageCircle, ArrowRight, Activity, Bone, Scissors, Phone } from 'lucide-react';
import { motion } from 'framer-motion';
import EnHeader from '@/components/EnHeader.jsx';
import EnFooter from '@/components/EnFooter.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';
const EnHomePage = () => {
  const featuredServices = [{
    icon: Activity,
    title: 'Sports Injuries',
    description: 'Specialized treatment for athletes and active individuals, focused on a fast and safe recovery.'
  }, {
    icon: Scissors,
    title: 'Arthroscopy',
    description: 'Minimally invasive procedures for joints, reducing pain and recovery time.'
  }, {
    icon: Bone,
    title: 'Fractures and Dislocations',
    description: 'Comprehensive management of complex and simple fractures with the most advanced surgical techniques.'
  }];
  return <WatermarkBackground>
      <Helmet>
        <html lang="en" />
        <title>Dr. Calvario | Naval Traumatologist and Orthopedist in Pto. Vallarta</title>
        <meta name="description" content="Book an appointment: 24H Emergencies, Fractures and Dislocations, Back and neck pain, Knee pain, Knee Surgery, Foot and ankle pain, Hip Fracture." />
        <meta name="robots" content="index, follow" />
        <link rel="alternate" hrefLang="es" href="/" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <EnHeader />
        
        <main className="flex-grow">
          {/* Hero Section */}
          <section id="hero" className="relative min-h-[100svh] flex items-start md:items-center justify-center overflow-hidden pt-12 sm:pt-20 md:pt-0 pb-24">
            {/* Dynamic Background Video */}
            <div className="absolute inset-0 z-0">
              <video autoPlay loop muted playsInline preload="auto" poster="https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/b59816235592060d9536831ade360475.png" className="w-full h-full object-cover object-center">
                <source src="https://files.catbox.moe/rde9f1.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0 bg-black/35 mix-blend-multiply"></div>
              <div className="absolute inset-0 bg-gradient-to-b from-primary/60 via-primary/30 to-background"></div>
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center w-full">
              <motion.div initial={{
              opacity: 0,
              y: 30
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.8
            }} className="max-w-4xl mx-auto">
                <div className="inline-block bg-white/10 backdrop-blur-md border border-white/20 p-8 md:p-12 rounded-3xl shadow-2xl w-full sm:w-auto">
                  <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-white leading-tight text-shadow-lg" style={{
                  fontFamily: 'Playfair Display, serif',
                  letterSpacing: '-0.02em'
                }}>
                    Dr. Calvario
                  </h1>
                  
                  <div className="w-32 h-1 bg-accent mx-auto my-6 rounded-full"></div>
                  
                  <h2 className="text-2xl md:text-3xl lg:text-4xl text-white/90 font-bold tracking-widest uppercase text-shadow-md">
                    NAVY-TRAINED ORTHOPEDIC SURGEON
                  </h2>
                  
                  <h3 className="text-xl md:text-2xl lg:text-3xl text-white/80 font-semibold tracking-wider uppercase mt-3 mb-6 text-shadow-md">
                    PUERTO VALLARTA
                  </h3>
                  
                  <div className="w-32 h-1 bg-accent mx-auto my-6 rounded-full"></div>
                  
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
                    <a href="https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                      <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-lg px-10 py-7 rounded-xl shadow-xl transition-all duration-300 hover:-translate-y-1 whitespace-normal h-auto">
                        <MessageCircle className="w-6 h-6 mr-3 flex-shrink-0" />
                        <span>Book your appointment today</span>
                      </Button>
                    </a>
                    <a href="tel:+523221016036" className="w-full sm:w-auto">
                      <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white font-bold text-lg px-10 py-7 rounded-xl shadow-xl transition-all duration-300 hover:-translate-y-1 whitespace-normal h-auto">
                        <Phone className="w-6 h-6 mr-3 flex-shrink-0" />
                        <span>Call now</span>
                      </Button>
                    </a>
                  </div>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Intro Section */}
          <section className="py-24 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <motion.div initial={{
                opacity: 0,
                x: -20
              }} whileInView={{
                opacity: 1,
                x: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.6
              }} className="card-standard">
                  <h2 className="text-heading text-3xl md:text-4xl mb-6">
                    Medical excellence with naval training
                  </h2>
                  <div className="w-20 h-1.5 bg-accent mb-8 rounded-full"></div>
                  <p className="text-body text-lg mb-6">
                    As a Naval Surgeon specializing in Orthopedics and Traumatology, my commitment is to provide the highest level of medical care, combining the discipline and rigor of naval training with the most innovative surgical techniques.
                  </p>
                  <p className="text-body text-lg mb-8">
                    My main goal is to restore your mobility and quality of life through precise diagnoses and personalized treatments, whether through conservative management or minimally invasive surgical interventions.
                  </p>
                  <Link to="/en/about" className="inline-flex items-center text-secondary font-bold hover:text-primary transition-colors text-lg group">
                    Learn more about my background
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </motion.div>
                
                <motion.div initial={{
                opacity: 0,
                x: 20
              }} whileInView={{
                opacity: 1,
                x: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.6
              }} className="relative">
                  <div className="absolute inset-0 bg-accent/20 rounded-3xl transform translate-x-4 translate-y-4"></div>
                  <img src="https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/gemini_generated_image_q3p45lq3p45lq3p4-Pm0HI.png" alt="Dr. Calvario" className="relative rounded-3xl shadow-2xl object-cover aspect-[4/5] w-full border-4 border-white" />
                </motion.div>
              </div>
            </div>
          </section>

          {/* Featured Services */}
          <section className="py-24 relative bg-white/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-3xl mx-auto mb-16">
                <h2 className="text-heading text-3xl md:text-4xl mb-4">
                  Services
                </h2>
                <p className="text-body text-lg">
                  Comprehensive solutions for musculoskeletal conditions.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {featuredServices.map((service, index) => <motion.div key={index} initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.5,
                delay: index * 0.1
              }} className="card-standard p-8">
                    <div className="w-16 h-16 bg-secondary/10 rounded-2xl flex items-center justify-center mb-6 text-secondary">
                      <service.icon className="w-8 h-8" />
                    </div>
                    <h3 className="text-heading text-xl mb-3">
                      {service.title}
                    </h3>
                    <p className="text-body">
                      {service.description}
                    </p>
                  </motion.div>)}
              </div>

              <div className="text-center mt-16">
                <Link to="/en/services">
                  <Button variant="outline" className="border-2 border-primary text-primary hover:bg-primary hover:text-white font-bold text-lg px-10 py-7 rounded-xl transition-all duration-300 bg-white shadow-lg">
                    View all services
                  </Button>
                </Link>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-24 relative">
            <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
              <div className="bg-primary rounded-[3rem] p-8 sm:p-12 md:p-20 shadow-2xl border-4 border-accent/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 -mt-20 -mr-20 w-80 h-80 bg-secondary/20 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-accent/20 rounded-full blur-3xl"></div>
                
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 relative z-10" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Recover your mobility today
                </h2>
                <p className="text-lg sm:text-xl text-white/80 mb-10 font-medium max-w-2xl mx-auto relative z-10">
                  Don't let pain limit your life. Schedule a specialized assessment and take the first step towards your recovery.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 relative z-10">
                  <a href="https://wa.me/5213221016036?text=Hello%2C%20I%20would%20like%20to%20schedule%20an%20appointment" target="_blank" rel="noopener noreferrer" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-secondary hover:bg-secondary/90 text-white font-bold text-base sm:text-xl px-6 sm:px-10 py-6 sm:py-7 rounded-xl shadow-2xl shadow-secondary/30 transition-all duration-300 hover:scale-105 whitespace-normal h-auto">
                      <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" />
                      <span>Book via WhatsApp</span>
                    </Button>
                  </a>
                  <a href="tel:+523221016036" className="w-full sm:w-auto">
                    <Button className="w-full sm:w-auto bg-white hover:bg-gray-100 text-primary font-bold text-base sm:text-xl px-6 sm:px-10 py-6 sm:py-7 rounded-xl shadow-2xl shadow-black/10 transition-all duration-300 hover:scale-105 whitespace-normal h-auto">
                      <Phone className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 flex-shrink-0" />
                      <span>Call now</span>
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </section>
        </main>

        <EnFooter />
      </div>
    </WatermarkBackground>;
};
export default EnHomePage;