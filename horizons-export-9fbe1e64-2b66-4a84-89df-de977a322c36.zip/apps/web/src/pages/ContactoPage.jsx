import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Send, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';

const ContactoPage = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = e => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      toast.success('Mensaje enviado correctamente. Nos pondremos en contacto a la brevedad.');
      e.target.reset();
    }, 1500);
  };

  return (
    <WatermarkBackground>
      <Helmet>
        <html lang="es" />
        <title>Contacto | Dr. Calvario</title>
        <meta name="description" content="Agenda tu consulta de traumatología y ortopedia en Puerto Vallarta. Contáctanos por teléfono, WhatsApp o correo electrónico." />
        <link rel="alternate" hrefLang="en" href="/en/contact" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow">
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div 
                initial={{ opacity: 0, y: 20 }} 
                animate={{ opacity: 1, y: 0 }} 
                className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block"
              >
                <h1 className="text-heading text-4xl md:text-5xl lg:text-6xl mb-4">
                  Contacto y Citas
                </h1>
                <p className="text-body text-xl max-w-2xl mx-auto">
                  Estamos listos para atenderte. Agenda tu valoración médica hoy mismo.
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
                
                {/* Contact Form */}
                <motion.div 
                  initial={{ opacity: 0, x: -20 }} 
                  animate={{ opacity: 1, x: 0 }} 
                  transition={{ duration: 0.6 }} 
                  className="lg:col-span-7"
                >
                  <div className="card-standard">
                    <h2 className="text-heading text-3xl mb-3">
                      Envíanos un mensaje
                    </h2>
                    <p className="text-body text-lg mb-10">
                      Completa el formulario y nuestro equipo se comunicará contigo para confirmar tu cita.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <Label htmlFor="nombre" className="text-primary font-bold text-base">Nombre completo</Label>
                          <Input id="nombre" required placeholder="Ej. Juan Pérez" className="bg-white text-primary border-border focus-visible:ring-primary py-6 rounded-xl shadow-sm" />
                        </div>
                        <div className="space-y-3">
                          <Label htmlFor="telefono" className="text-primary font-bold text-base">Teléfono</Label>
                          <Input id="telefono" type="tel" required placeholder="Ej. 322 123 4567" className="bg-white text-primary border-border focus-visible:ring-primary py-6 rounded-xl shadow-sm" />
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <Label htmlFor="email" className="text-primary font-bold text-base">Correo electrónico</Label>
                          <Input id="email" type="email" required placeholder="correo@ejemplo.com" className="bg-white text-primary border-border focus-visible:ring-primary py-6 rounded-xl shadow-sm" />
                        </div>
                        <div className="space-y-3">
                          <Label htmlFor="asunto" className="text-primary font-bold text-base">Asunto</Label>
                          <Input id="asunto" required placeholder="Ej. Consulta de primera vez" className="bg-white text-primary border-border focus-visible:ring-primary py-6 rounded-xl shadow-sm" />
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Label htmlFor="mensaje" className="text-primary font-bold text-base">Mensaje o motivo de consulta</Label>
                        <Textarea id="mensaje" required placeholder="Describe brevemente tus síntomas o motivo de la cita..." className="min-h-[150px] bg-white text-primary border-border focus-visible:ring-primary rounded-xl shadow-sm resize-none p-4" />
                      </div>

                      <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-7 text-lg rounded-xl shadow-lg transition-all duration-300">
                        {isSubmitting ? 'Enviando...' : <>
                            <Send className="w-5 h-5 mr-2" />
                            Enviar Mensaje
                          </>}
                      </Button>
                    </form>
                  </div>
                </motion.div>

                {/* Contact Info */}
                <motion.div 
                  initial={{ opacity: 0, x: 20 }} 
                  animate={{ opacity: 1, x: 0 }} 
                  transition={{ duration: 0.6, delay: 0.2 }} 
                  className="lg:col-span-5 space-y-8"
                >
                  <div className="bg-primary rounded-3xl p-8 sm:p-10 text-white shadow-2xl border-4 border-accent/20 relative overflow-hidden">
                    <div className="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-accent/20 rounded-full blur-2xl"></div>
                    
                    <h3 className="text-2xl sm:text-3xl font-bold text-white mb-8 relative z-10" style={{ fontFamily: 'Playfair Display, serif' }}>
                      Información Directa
                    </h3>
                    
                    <div className="space-y-8 relative z-10">
                      <div className="flex items-start gap-4 sm:gap-5">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0 border border-white/20">
                          <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs sm:text-sm text-white/70 mb-1 font-bold uppercase tracking-wider">Llamadas</p>
                          <a href="tel:+523221016036" className="text-sm sm:text-xl font-bold hover:text-accent transition-colors block truncate">
                            +52 322 101 60 36
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4 sm:gap-5">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0 border border-white/20">
                          <MessageCircle className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs sm:text-sm text-white/70 mb-1 font-bold uppercase tracking-wider">WhatsApp</p>
                          <a href="https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita" target="_blank" rel="noopener noreferrer" className="text-sm sm:text-xl font-bold hover:text-accent transition-colors block truncate">
                            +52 322 101 60 36
                          </a>
                        </div>
                      </div>

                      <div className="flex items-start gap-4 sm:gap-5">
                        <div className="w-10 h-10 sm:w-12 sm:h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0 border border-white/20">
                          <Mail className="w-5 h-5 sm:w-6 sm:h-6 text-accent" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs sm:text-sm text-white/70 mb-1 font-bold uppercase tracking-wider">Correo Electrónico</p>
                          <a href="mailto:pacientes@doctorcalvario.com" className="text-sm sm:text-lg font-bold hover:text-accent transition-colors block truncate">
                            pacientes@doctorcalvario.com
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                  <a 
                    href="https://sanmare.mx/es" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="block rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white h-64 relative group cursor-pointer"
                  >
                    <img src="https://images.unsplash.com/photo-1565647946321-a146ac24a220" alt="Clínica" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-primary/70 flex items-center justify-center transition-colors duration-300 group-hover:bg-primary/80">
                      <div className="text-center p-6">
                        <MapPin className="w-10 h-10 text-accent mx-auto mb-3 transition-transform duration-300 group-hover:-translate-y-2" />
                        <p className="text-white font-bold text-xl mb-1" style={{ fontFamily: 'Playfair Display, serif' }}>
                          SANMARÉ Health-Care Group
                        </p>
                        <p className="text-white/80 font-medium">Puerto Vallarta, Jal.</p>
                        <span className="inline-block mt-4 px-4 py-2 bg-white/20 rounded-full text-white text-sm font-bold backdrop-blur-sm border border-white/30 group-hover:bg-white/30 transition-colors">
                          Visitar sitio web
                        </span>
                      </div>
                    </div>
                  </a>

                </motion.div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>
  );
};

export default ContactoPage;