import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Anchor, Target, Heart, Award } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import WatermarkBackground from '@/components/WatermarkBackground.jsx';
const AcercaDePage = () => {
  const values = [{
    icon: Anchor,
    title: 'Disciplina Naval',
    description: 'Rigor, ética y profesionalismo en cada diagnóstico y procedimiento quirúrgico.'
  }, {
    icon: Target,
    title: 'Precisión',
    description: 'Enfoque meticuloso en el tratamiento para asegurar los mejores resultados funcionales.'
  }, {
    icon: Heart,
    title: 'Empatía',
    description: 'Atención humana y comprensiva, entendiendo el impacto del dolor en la vida del paciente.'
  }, {
    icon: Award,
    title: 'Excelencia',
    description: 'Actualización médica continua para ofrecer las técnicas más avanzadas y seguras.'
  }];
  return <WatermarkBackground>
      <Helmet>
        <html lang="es" />
        <title>Acerca del Dr. Calvario | Ortopedia y Traumatología</title>
        <meta name="description" content="Conoce la trayectoria del Dr. Hugo Adrián Sánchez Calvario, Médico Cirujano Naval y Especialista en Ortopedia y Traumatología." />
        <link rel="alternate" hrefLang="en" href="/en/about" />
      </Helmet>
      <div className="min-h-screen flex flex-col bg-transparent">
        <Header />

        <main className="flex-grow">
          {/* Page Header */}
          <section className="py-20 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} animate={{
              opacity: 1,
              y: 0
            }} className="bg-white/90 backdrop-blur-md p-10 rounded-3xl shadow-xl border border-border inline-block">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-primary mb-4" style={{
                fontFamily: 'Playfair Display, serif'
              }}>
                  Acerca del Dr. Calvario
                </h1>
                <p className="text-xl text-primary/80 max-w-2xl mx-auto font-medium">
                  Disciplina naval y excelencia médica al cuidado de tu salud articular.
                </p>
              </motion.div>
            </div>
          </section>

          {/* Bio Section */}
          <section className="py-16 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
                <motion.div initial={{
                opacity: 0,
                x: -20
              }} animate={{
                opacity: 1,
                x: 0
              }} transition={{
                duration: 0.6
              }} className="lg:col-span-5">
                  <div className="sticky top-32">
                    <div className="relative rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
                      <img src="https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/gemini_generated_image_rchh4mrchh4mrchh-CCnae.png" alt="Dr. Hugo Adrián Sánchez Calvario" className="w-full aspect-[3/4] object-cover" />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-primary/95 via-primary/80 to-transparent p-8 pt-24">
                        <p className="text-accent font-bold text-xl mb-1" style={{
                        fontFamily: 'Playfair Display, serif'
                      }}>
                          Dr. Hugo Adrián Sánchez Calvario
                        </p>
                        <p className="text-white/90 font-medium">Ortopedia y Traumatología</p>
                      </div>
                    </div>
                  </div>
                </motion.div>

                <motion.div initial={{
                opacity: 0,
                x: 20
              }} animate={{
                opacity: 1,
                x: 0
              }} transition={{
                duration: 0.6,
                delay: 0.2
              }} className="lg:col-span-7">
                  <div className="bg-white rounded-3xl p-8 md:p-10 shadow-xl border border-border mb-10">
                    <h2 className="text-2xl font-bold text-primary mb-4" style={{
                    fontFamily: 'Playfair Display, serif'
                  }}>
                      Cédula Profesional
                    </h2>
                    <div className="w-16 h-1.5 bg-accent mb-6 rounded-full"></div>
                    
                    <div className="mb-6">
                      <h3 className="text-2xl font-bold text-primary mb-2">
                        Hugo Adrián Sánchez Calvario
                      </h3>
                      <p className="text-lg text-secondary font-bold">
                        Médico Cirujano Naval – Especialista en Ortopedia y Traumatología
                      </p>
                    </div>

                    <div className="flex items-center gap-3 bg-primary/5 p-4 rounded-xl border border-primary/10 inline-flex">
                      <Award className="w-6 h-6 text-accent" />
                      <p className="text-primary font-medium">
                        Cédula Profesional: <span className="font-bold">09653434</span>
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-3xl p-8 md:p-10 shadow-xl border border-border prose prose-lg prose-p:text-primary/80 prose-p:font-medium prose-headings:text-primary prose-headings:font-playfair max-w-none">
                    <h3 className="text-3xl font-bold mb-6" style={{
                    fontFamily: 'Playfair Display, serif'
                  }}>
                      Trayectoria y Vocación
                    </h3>
                    <p>
                      Con una sólida formación forjada en las instituciones médicas navales más prestigiosas, mi práctica profesional se distingue por el rigor científico, la disciplina y un profundo compromiso con el bienestar de mis pacientes.
                    </p>
                    <p>
                      Mi especialización en Ortopedia y Traumatología me permite abordar una amplia gama de padecimientos del sistema musculoesquelético, desde lesiones deportivas agudas hasta condiciones degenerativas crónicas que afectan la calidad de vida.
                    </p>
                    <p>
                      A lo largo de mi carrera, he tenido el honor de formarme y colaborar en centros de excelencia médica tanto en México como en el extranjero, incluyendo el Centro Médico Naval y el Navy Medical Center en San Diego. Esta exposición internacional me ha dotado de una perspectiva global y dominio de técnicas quirúrgicas de vanguardia.
                    </p>
                    <p>
                      --------------------------------------------------------------------
                    </p>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* Values Section */}
          <section className="py-24 relative">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <div className="bg-white/90 backdrop-blur-sm p-8 rounded-3xl shadow-lg border border-border inline-block mx-auto">
                  <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4" style={{
                  fontFamily: 'Playfair Display, serif'
                }}>
                    Filosofía de Atención
                  </h2>
                  <p className="text-primary/80 max-w-2xl mx-auto text-lg font-medium">
                    Principios fundamentales que guían mi práctica médica diaria.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {values.map((value, index) => <motion.div key={index} initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} viewport={{
                once: true
              }} transition={{
                duration: 0.5,
                delay: index * 0.1
              }} className="bg-white rounded-3xl p-8 shadow-xl hover:-translate-y-1 transition-transform duration-300 border border-border text-center flex flex-col items-center">
                    <div className="w-16 h-16 bg-primary/5 rounded-2xl flex items-center justify-center mb-6">
                      <value.icon className="w-8 h-8 text-secondary" />
                    </div>
                    <h3 className="text-xl font-bold text-primary mb-3" style={{
                  fontFamily: 'Playfair Display, serif'
                }}>
                      {value.title}
                    </h3>
                    <p className="text-primary/70 font-medium leading-relaxed">
                      {value.description}
                    </p>
                  </motion.div>)}
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </WatermarkBackground>;
};
export default AcercaDePage;