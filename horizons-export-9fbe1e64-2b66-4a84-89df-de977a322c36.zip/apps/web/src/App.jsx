import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from './components/ScrollToTop.jsx';
import MaintenanceBanner from './components/MaintenanceBanner.jsx';
import LanguageSwitcher from './components/LanguageSwitcher.jsx';
import FloatingWhatsAppButton from './components/FloatingWhatsAppButton.jsx';

// Spanish Pages
import HomePage from './pages/HomePage.jsx';
import AcercaDePage from './pages/AcercaDePage.jsx';
import FormacionPage from './pages/FormacionPage.jsx';
import ServiciosPage from './pages/ServiciosPage.jsx';
import PadecimientosPage from './pages/PadecimientosPage.jsx';
import FracturasPage from './pages/FracturasPage.jsx';
import UbicacionPage from './pages/UbicacionPage.jsx';
import TestimoniosPage from './pages/TestimoniosPage.jsx';
import ContactoPage from './pages/ContactoPage.jsx';

// English Pages
import EnHomePage from './pages/EnHomePage.jsx';
import EnAboutPage from './pages/EnAboutPage.jsx';
import EnTrainingPage from './pages/EnTrainingPage.jsx';
import EnServicesPage from './pages/EnServicesPage.jsx';
import EnConditionsPage from './pages/EnConditionsPage.jsx';
import EnLocationPage from './pages/EnLocationPage.jsx';
import EnContactPage from './pages/EnContactPage.jsx';

function App() {
  return (
    <Router>
      <ScrollToTop />
      <MaintenanceBanner />
      <Routes>
        {/* Spanish Routes */}
        <Route path="/" element={<HomePage />} />
        <Route path="/acerca-de" element={<AcercaDePage />} />
        <Route path="/formacion" element={<FormacionPage />} />
        <Route path="/servicios" element={<ServiciosPage />} />
        <Route path="/padecimientos" element={<PadecimientosPage />} />
        <Route path="/fracturas" element={<FracturasPage />} />
        <Route path="/ubicacion" element={<UbicacionPage />} />
        <Route path="/testimonios" element={<TestimoniosPage />} />
        <Route path="/contacto" element={<ContactoPage />} />

        {/* English Routes */}
        <Route path="/en" element={<EnHomePage />} />
        <Route path="/en/about" element={<EnAboutPage />} />
        <Route path="/en/training" element={<EnTrainingPage />} />
        <Route path="/en/services" element={<EnServicesPage />} />
        <Route path="/en/conditions" element={<EnConditionsPage />} />
        <Route path="/en/location" element={<EnLocationPage />} />
        <Route path="/en/contact" element={<EnContactPage />} />
      </Routes>
      <LanguageSwitcher />
      <FloatingWhatsAppButton />
      <Toaster />
    </Router>
  );
}

export default App;