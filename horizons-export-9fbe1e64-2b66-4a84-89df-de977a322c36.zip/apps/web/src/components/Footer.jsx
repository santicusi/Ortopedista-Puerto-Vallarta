import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Phone, Mail, MessageCircle } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const logoUrl = 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/07e2358c3852739480be01da4eaebd77.png';

  const navItems = [
    { name: 'Inicio', path: '/' },
    { name: 'Acerca de', path: '/acerca-de' },
    { name: 'Formación', path: '/formacion' },
    { name: 'Servicios', path: '/servicios' },
    { name: 'Padecimientos', path: '/padecimientos' },
    { name: 'Ubicación', path: '/ubicacion' },
    { name: 'Contacto', path: '/contacto' }
  ];

  return (
    <footer className="bg-white text-primary border-t-4 border-accent relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          
          {/* Branding */}
          <div>
            <div className="mb-6">
              <img src={logoUrl} alt="Dr. Calvario Logo" className="h-16 w-auto object-contain mb-4" />
              <h2 className="text-2xl font-black text-primary mb-1" style={{ fontFamily: 'Playfair Display, serif' }}>
                Doctor Calvario
              </h2>
            </div>
            <div className="text-primary/80 leading-relaxed max-w-md font-medium space-y-1">
              <p className="font-bold text-primary text-lg">Dr. Hugo Adrián Sánchez Calvario</p>
              <p>Médico Cirujano Naval</p>
              <p>Especialista en Ortopedia y Traumatología</p>
              <p className="text-secondary font-bold pt-3 uppercase tracking-wider text-sm">SANMARÉ Health-Care Group</p>
            </div>
          </div>

          {/* Quick Links - Centered */}
          <div className="flex flex-col md:items-center">
            <div className="w-full md:w-auto">
              <h3 className="text-lg font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
                Enlaces Rápidos
              </h3>
              <nav className="flex flex-col gap-3">
                {navItems.map((item) => (
                  <Link 
                    key={item.path} 
                    to={item.path} 
                    className="text-primary/80 hover:text-secondary font-medium transition-colors duration-200 flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-accent/50"></span>
                    {item.name}
                  </Link>
                ))}
              </nav>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-lg font-bold text-primary mb-6" style={{ fontFamily: 'Playfair Display, serif' }}>
              Contacto
            </h3>
            <div className="flex flex-col gap-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-secondary flex-shrink-0 mt-1" />
                <a href="https://maps.app.goo.gl/DEMy44D3FW8R5SVg8" target="_blank" rel="noopener noreferrer" className="text-primary/80 text-sm leading-relaxed font-medium hover:text-secondary transition-colors">
                  Blvd. Francisco Medina Ascencio 2735-9, Zona Hotelera Nte., 48333 Puerto Vallarta, Jal.
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-secondary flex-shrink-0" />
                <a href="tel:+523221016036" className="text-primary/80 text-sm font-medium hover:text-secondary transition-colors">
                  +52 322 101 60 36
                </a>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="w-5 h-5 text-secondary flex-shrink-0" />
                <a href="https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita" target="_blank" rel="noopener noreferrer" className="text-primary/80 text-sm font-medium hover:text-secondary transition-colors">
                  +52 322 101 60 36
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-secondary flex-shrink-0" />
                <a href="mailto:pacientes@doctorcalvario.com" className="text-primary/80 text-sm font-medium hover:text-secondary transition-colors">
                  pacientes@doctorcalvario.com
                </a>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-16 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-primary/60 text-sm font-medium text-center md:text-left">
            © {currentYear} Dr. Calvario. Todos los derechos reservados.
          </p>
          <div className="flex items-center gap-6">
            <Link to="#" className="text-primary/60 hover:text-secondary font-medium text-sm transition-colors">
              Aviso de Privacidad
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;