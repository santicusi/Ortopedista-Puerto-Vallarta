import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Calendar } from 'lucide-react';

const BookingForm = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    telefono: '',
    motivo: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.nombre || !formData.telefono || !formData.motivo) {
      toast.error('Por favor complete todos los campos');
      return;
    }

    setIsSubmitting(true);

    const message = `Hola Dr. Calvario, me gustaría agendar una consulta.%0A%0ANombre: ${formData.nombre}%0ATeléfono: ${formData.telefono}%0AMotivo: ${formData.motivo}`;
    const whatsappUrl = `https://wa.me/5215512345678?text=${message}`;

    setTimeout(() => {
      window.open(whatsappUrl, '_blank');
      toast.success('Redirigiendo a WhatsApp');
      setFormData({ nombre: '', telefono: '', motivo: '' });
      setIsSubmitting(false);
    }, 500);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="nombre" className="text-foreground">Nombre completo</Label>
        <Input
          id="nombre"
          name="nombre"
          type="text"
          value={formData.nombre}
          onChange={handleChange}
          placeholder="Ej. María González"
          className="mt-1.5 bg-background text-foreground"
          required
        />
      </div>
      <div>
        <Label htmlFor="telefono" className="text-foreground">Teléfono / WhatsApp</Label>
        <Input
          id="telefono"
          name="telefono"
          type="tel"
          value={formData.telefono}
          onChange={handleChange}
          placeholder="Ej. 55 1234 5678"
          className="mt-1.5 bg-background text-foreground"
          required
        />
      </div>
      <div>
        <Label htmlFor="motivo" className="text-foreground">Motivo de consulta</Label>
        <Textarea
          id="motivo"
          name="motivo"
          value={formData.motivo}
          onChange={handleChange}
          placeholder="Describa brevemente su motivo de consulta"
          className="mt-1.5 bg-background text-foreground resize-none"
          rows={3}
          required
        />
      </div>
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full bg-accent hover:bg-accent/90 text-white font-semibold transition-all duration-200 active:scale-[0.98]"
      >
        <Calendar className="w-4 h-4 mr-2" />
        {isSubmitting ? 'Procesando...' : 'Agendar consulta'}
      </Button>
    </form>
  );
};

export default BookingForm;