import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Globe } from 'lucide-react';
import { motion } from 'framer-motion';

const routeMap = {
  '/': '/en',
  '/acerca-de': '/en/about',
  '/formacion': '/en/training',
  '/servicios': '/en/services',
  '/padecimientos': '/en/conditions',
  '/ubicacion': '/en/location',
  '/contacto': '/en/contact',
  '/en': '/',
  '/en/about': '/acerca-de',
  '/en/training': '/formacion',
  '/en/services': '/servicios',
  '/en/conditions': '/padecimientos',
  '/en/location': '/ubicacion',
  '/en/contact': '/contacto',
};

const LanguageSwitcher = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Normalize trailing slashes for matching
  const currentPath = location.pathname.endsWith('/') && location.pathname !== '/' 
    ? location.pathname.slice(0, -1) 
    : location.pathname;
    
  const isEnglish = currentPath.startsWith('/en');

  const toggleLanguage = () => {
    const targetRoute = routeMap[currentPath] || (isEnglish ? '/' : '/en');
    navigate(targetRoute);
  };

  return (
    <motion.button
      onClick={toggleLanguage}
      className="fixed bottom-6 left-6 z-50 bg-primary hover:bg-primary/90 text-white rounded-full px-5 py-3.5 shadow-lg shadow-black/20 transition-all duration-200 active:scale-[0.98] focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 flex items-center justify-center gap-2 font-bold"
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.3, delay: 0.6 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      aria-label={isEnglish ? "Switch to Spanish" : "Switch to English"}
    >
      <Globe className="w-5 h-5" />
      <span>{isEnglish ? 'ESP' : 'ENG'}</span>
    </motion.button>
  );
};

export default LanguageSwitcher;