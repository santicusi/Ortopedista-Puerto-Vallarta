import React, { useState, useEffect } from 'react';
import { X, AlertCircle } from 'lucide-react';

const MaintenanceBanner = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const isClosed = sessionStorage.getItem('maintenanceBannerClosed');
    if (!isClosed) {
      setIsVisible(true);
    }
  }, []);

  const handleClose = () => {
    setIsVisible(false);
    sessionStorage.setItem('maintenanceBannerClosed', 'true');
  };

  if (!isVisible) return null;

  return (
    <div className="bg-primary text-primary-foreground px-4 py-2.5 text-sm font-medium relative z-50 flex items-center justify-center shadow-md">
      <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-center pr-8 text-center">
        <AlertCircle className="w-4 h-4 text-accent flex-shrink-0" />
        <p>
          Sitio en mantenimiento. Para agendar consulta, escríbenos por{' '}
          <a 
            href="https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-accent hover:text-white underline underline-offset-2 font-bold transition-colors"
          >
            WhatsApp
          </a>.
        </p>
      </div>
      <button 
        onClick={handleClose}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-primary-foreground/80 hover:text-white transition-colors p-1"
        aria-label="Cerrar banner"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
};

export default MaintenanceBanner;