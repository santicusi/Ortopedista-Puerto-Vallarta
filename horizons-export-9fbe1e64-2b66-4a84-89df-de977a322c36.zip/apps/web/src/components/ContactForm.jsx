import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Send } from 'lucide-react';

const ContactForm = () => {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    asunto: '',
    mensaje: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.nombre || !formData.email || !formData.telefono || !formData.asunto || !formData.mensaje) {
      toast.error('Por favor complete todos los campos');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      toast.error('Por favor ingrese un email válido');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const contactData = {
        ...formData,
        fecha: new Date().toISOString(),
        id: Date.now()
      };

      const existingContacts = JSON.parse(localStorage.getItem('contactos') || '[]');
      existingContacts.push(contactData);
      localStorage.setItem('contactos', JSON.stringify(existingContacts));

      toast.success('Mensaje enviado correctamente. Nos pondremos en contacto pronto.');
      setFormData({ nombre: '', email: '', telefono: '', asunto: '', mensaje: '' });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="nombre" className="text-foreground">Nombre completo</Label>
          <Input
            id="nombre"
            name="nombre"
            type="text"
            value={formData.nombre}
            onChange={handleChange}
            placeholder="Ej. Carlos Ramírez"
            className="mt-1.5 bg-background text-foreground"
            required
          />
        </div>
        <div>
          <Label htmlFor="email" className="text-foreground">Correo electrónico</Label>
          <Input
            id="email"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="ejemplo@correo.com"
            className="mt-1.5 bg-background text-foreground"
            required
          />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="telefono" className="text-foreground">Teléfono</Label>
          <Input
            id="telefono"
            name="telefono"
            type="tel"
            value={formData.telefono}
            onChange={handleChange}
            placeholder="55 1234 5678"
            className="mt-1.5 bg-background text-foreground"
            required
          />
        </div>
        <div>
          <Label htmlFor="asunto" className="text-foreground">Asunto</Label>
          <Input
            id="asunto"
            name="asunto"
            type="text"
            value={formData.asunto}
            onChange={handleChange}
            placeholder="Ej. Consulta sobre tratamiento"
            className="mt-1.5 bg-background text-foreground"
            required
          />
        </div>
      </div>
      <div>
        <Label htmlFor="mensaje" className="text-foreground">Mensaje</Label>
        <Textarea
          id="mensaje"
          name="mensaje"
          value={formData.mensaje}
          onChange={handleChange}
          placeholder="Escriba su mensaje aquí..."
          className="mt-1.5 bg-background text-foreground resize-none"
          rows={6}
          required
        />
      </div>
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full md:w-auto bg-accent hover:bg-accent/90 text-white font-semibold px-8 transition-all duration-200 active:scale-[0.98]"
      >
        <Send className="w-4 h-4 mr-2" />
        {isSubmitting ? 'Enviando...' : 'Enviar mensaje'}
      </Button>
    </form>
  );
};

export default ContactForm;