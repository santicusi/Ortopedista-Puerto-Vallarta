import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, MessageCircle } from 'lucide-react';

const Header = () => {
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Inicio', path: '/' },
    { name: 'Acerca de', path: '/acerca-de' },
    { name: 'Formación', path: '/formacion' },
    { name: 'Servicios', path: '/servicios' },
    { name: 'Padecimientos', path: '/padecimientos' },
    { name: 'Ubicación', path: '/ubicacion' },
    { name: 'Contacto', path: '/contacto' }
  ];

  const isActive = (path) => location.pathname === path;

  const handleWhatsApp = () => {
    window.open('https://wa.me/5213221016036?text=Hola%2C%20quisiera%20agendar%20una%20cita', '_blank');
  };

  const logoUrl = 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/07e2358c3852739480be01da4eaebd77.png';

  return (
    <header className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-border/50 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 md:h-24">
          <Link to="/" className="flex items-center gap-3 md:gap-4 group flex-shrink-0 max-w-[75%] md:max-w-none">
            <img 
              src={logoUrl} 
              alt="Dr. Calvario Logo" 
              className="h-[58px] md:h-[76px] w-auto object-contain transition-transform duration-300 group-hover:scale-105"
            />
            <div className="flex flex-col justify-center">
              <span className="text-lg md:text-2xl lg:text-3xl font-black text-primary leading-none tracking-tight" style={{ fontFamily: 'Playfair Display, serif' }}>
                Dr. Calvario
              </span>
              <span className="text-[0.65rem] md:text-xs text-secondary font-bold uppercase tracking-widest mt-1 truncate">
                Ortopedista Naval
              </span>
              <span className="text-[0.65rem] md:text-xs text-primary/70 font-bold uppercase tracking-widest truncate">
                Puerto Vallarta
              </span>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`px-3 py-2 rounded-full text-sm font-bold transition-all duration-200 ${
                  isActive(item.path)
                    ? 'text-primary bg-primary/10'
                    : 'text-primary/70 hover:text-primary hover:bg-primary/5'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <Button 
              onClick={handleWhatsApp}
              className="bg-secondary hover:bg-secondary/90 text-white font-bold rounded-full px-6 transition-all duration-200 active:scale-[0.98] shadow-md shadow-secondary/20"
            >
              <MessageCircle className="w-4 h-4 mr-2" />
              Agendar Cita
            </Button>
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            <Button 
              onClick={handleWhatsApp}
              size="icon"
              className="bg-secondary hover:bg-secondary/90 text-white rounded-full shadow-md h-9 w-9"
            >
              <MessageCircle className="w-4 h-4" />
            </Button>
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-primary hover:bg-primary/10">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px] bg-white/95 backdrop-blur-xl border-l border-border">
                <div className="mt-8 mb-8 flex items-center gap-4">
                  <img 
                    src={logoUrl} 
                    alt="Dr. Calvario Logo" 
                    className="h-[58px] w-auto object-contain"
                  />
                  <div className="flex flex-col justify-center">
                    <span className="text-xl font-black text-primary leading-none tracking-tight" style={{ fontFamily: 'Playfair Display, serif' }}>
                      Dr. Calvario
                    </span>
                    <span className="text-[0.65rem] text-secondary font-bold uppercase tracking-widest mt-1">
                      Ortopedista Naval
                    </span>
                    <span className="text-[0.65rem] text-primary/70 font-bold uppercase tracking-widest">
                      Puerto Vallarta
                    </span>
                  </div>
                </div>
                <nav className="flex flex-col gap-2">
                  {navItems.map((item) => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setIsOpen(false)}
                      className={`px-4 py-3 rounded-xl text-base font-bold transition-all duration-200 ${
                        isActive(item.path)
                          ? 'text-primary bg-primary/10'
                          : 'text-primary/70 hover:text-primary hover:bg-primary/5'
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <div className="pt-6 mt-4 border-t border-border/50">
                    <Button 
                      onClick={() => {
                        handleWhatsApp();
                        setIsOpen(false);
                      }}
                      className="w-full bg-secondary hover:bg-secondary/90 text-white font-bold py-6 rounded-xl shadow-md"
                    >
                      <MessageCircle className="w-5 h-5 mr-2" />
                      Agendar por WhatsApp
                    </Button>
                  </div>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;