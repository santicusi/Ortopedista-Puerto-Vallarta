import React from 'react';
import { GraduationCap } from 'lucide-react';
import { motion } from 'framer-motion';

const CredentialCard = ({ title, institution, year, description, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="flex gap-6 items-start"
    >
      <div className="flex-shrink-0 w-12 h-12 bg-accent/10 rounded-xl flex items-center justify-center">
        <GraduationCap className="w-6 h-6 text-accent" />
      </div>
      <div className="flex-1">
        <div className="flex items-baseline gap-3 mb-2">
          <h3 className="text-xl font-semibold text-foreground" style={{ fontFamily: 'Playfair Display, serif' }}>
            {title}
          </h3>
          <span className="text-sm font-medium text-accent">{year}</span>
        </div>
        <p className="text-muted-foreground font-medium mb-2">{institution}</p>
        {description && (
          <p className="text-muted-foreground leading-relaxed">{description}</p>
        )}
      </div>
    </motion.div>
  );
};

export default CredentialCard;