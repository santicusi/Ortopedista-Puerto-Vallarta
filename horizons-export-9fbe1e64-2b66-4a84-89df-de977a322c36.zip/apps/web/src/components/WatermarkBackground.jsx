import React from 'react';

const logoUrl = 'https://horizons-cdn.hostinger.com/9fbe1e64-2b66-4a84-89df-de977a322c36/07e2358c3852739480be01da4eaebd77.png';

const watermarks = [
  { top: '5%', left: '10%', rotate: '15deg' },
  { top: '25%', right: '15%', rotate: '45deg' },
  { top: '45%', left: '20%', rotate: '90deg' },
  { top: '65%', right: '25%', rotate: '135deg' },
  { top: '85%', left: '15%', rotate: '180deg' },
  { top: '15%', left: '50%', rotate: '225deg' },
  { top: '55%', left: '60%', rotate: '270deg' },
  { top: '75%', right: '40%', rotate: '315deg' },
];

const WatermarkBackground = ({ children }) => {
  return (
    <div className="relative min-h-screen w-full bg-background z-0">
      <div className="fixed inset-0 pointer-events-none z-[-1] overflow-hidden opacity-[0.12] mix-blend-multiply">
        {watermarks.map((wm, i) => (
          <img
            key={i}
            src={logoUrl}
            alt=""
            className="absolute object-contain w-32 h-32"
            style={{ 
              top: wm.top, 
              left: wm.left, 
              right: wm.right,
              transform: `rotate(${wm.rotate})`
            }}
            aria-hidden="true"
          />
        ))}
      </div>
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};

export default WatermarkBackground;